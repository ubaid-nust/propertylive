import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
    const hashedPassword = await bcrypt.hash('123456789', 10);

    const admin = await prisma.user.upsert({
        where: { email: 'ubaid1@gmail.com' },
        update: {}, // No update needed since this is an upsert
        create: {
            id: '123',
            name: 'Khawaja Ubaid',
            email: 'ubaid1@gmail.com',
            password: hashedPassword,
            phone: '03123456789',
            role: 'ADMIN',
        },
    });

    console.log('Admin created:', admin);
}

main()
    .catch((e) => {
        console.error(e);
        process.exit(1);
    })
    .finally(() => prisma.$disconnect());
