-- CreateEnum
CREATE TYPE "UserRole" AS ENUM ('USER', 'AGENT', 'OWNER', 'BUILDER', 'ADMIN');

-- CreateEnum
CREATE TYPE "AreaUnit" AS ENUM ('SQM', 'SQFT', 'ACRE', 'HECTARE', 'SQYRD');

-- CreateEnum
CREATE TYPE "Authority" AS ENUM ('COH', 'MLGPW', 'RDA');

-- CreateEnum
CREATE TYPE "AgeofC" AS ENUM ('NEW_CONSTRUCTION', 'LESS_THAN_FIVE_YEARS', 'FIVE_TO_TEN_YEARS', 'FIFTEEN_TO_TWENTY_YEARS', 'ABOVE_TWENTY_YEARS');

-- CreateEnum
CREATE TYPE "PostedAs" AS ENUM ('OWNER', 'AGENT', 'BUILDER');

-- CreateEnum
CREATE TYPE "PropertyType" AS ENUM ('FLAT', 'HOUSE', 'VILLA', 'OFFICE_SPACE', 'SHOP', 'PLOT', 'PG', 'OTHER');

-- CreateEnum
CREATE TYPE "PropertyCategory" AS ENUM ('COMMERCIAL', 'RESIDENTIAL');

-- CreateEnum
CREATE TYPE "PropertyStatus" AS ENUM ('FOR_SALE', 'FOR_RENT', 'SOLD', 'RENTED');

-- CreateEnum
CREATE TYPE "FurnishingStatus" AS ENUM ('FURNISHED', 'SEMI_FURNISHED', 'UNFURNISHED');

-- CreateEnum
CREATE TYPE "Facing" AS ENUM ('EAST', 'WEST', 'NORTH', 'SOUTH', 'NORTH_EAST', 'NORTH_WEST', 'SOUTH_EAST', 'SOUTH_WEST');

-- CreateEnum
CREATE TYPE "PossessionStatus" AS ENUM ('READY_TO_MOVE', 'UNDER_CONSTRUCTION');

-- CreateEnum
CREATE TYPE "TenantsPreferred" AS ENUM ('BACHELORS', 'FAMILY');

-- CreateEnum
CREATE TYPE "SaleType" AS ENUM ('NEW', 'RESALE');

-- CreateEnum
CREATE TYPE "PGGender" AS ENUM ('BOYS', 'GIRLS', 'BOTH');

-- CreateEnum
CREATE TYPE "OccupancyType" AS ENUM ('SINGLE', 'DOUBLE', 'TRIPLE');

-- CreateEnum
CREATE TYPE "PreferredTenants" AS ENUM ('STUDENTS', 'PROFESSIONALS');

-- CreateEnum
CREATE TYPE "ServiceCategory" AS ENUM ('RENTAL', 'BUY_SELL', 'HOME', 'ADVICE');

-- CreateEnum
CREATE TYPE "BlogCategory" AS ENUM ('LIFESTYLE', 'POLICIES', 'FINANCE_LEGAL', 'RESEARCH', 'CITY_NEWS');

-- CreateEnum
CREATE TYPE "LoanStatus" AS ENUM ('PENDING', 'APPROVED', 'REJECTED');

-- CreateEnum
CREATE TYPE "NotificationType" AS ENUM ('INQUIRY', 'PROPERTY_UPDATE', 'SYSTEM_MESSAGE', 'LOAN_STATUS');

-- CreateEnum
CREATE TYPE "AvailableFrom" AS ENUM ('IMMEDIATELY', 'ONE_WEEK', 'TWO_WEEKS', 'ONE_MONTH', 'THREE_MONTHS', 'SIX_MONTHS', 'ONE_YEAR');

-- CreateTable
CREATE TABLE "User" (
    "id" TEXT NOT NULL,
    "name" TEXT,
    "email" TEXT,
    "emailVerified" TIMESTAMP(3),
    "image" TEXT,
    "password" TEXT,
    "phone" TEXT,
    "role" "UserRole" NOT NULL DEFAULT 'USER',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Property" (
    "id" TEXT NOT NULL,
    "propertyType" TEXT,
    "title" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "price" DOUBLE PRECISION NOT NULL,
    "type" TEXT NOT NULL,
    "category" "PropertyCategory" NOT NULL,
    "status" "PropertyStatus" NOT NULL,
    "postedAs" "PostedAs" NOT NULL,
    "bedrooms" INTEGER,
    "bathrooms" INTEGER,
    "balcony" INTEGER,
    "area" DOUBLE PRECISION NOT NULL,
    "address" TEXT NOT NULL,
    "city" TEXT NOT NULL,
    "state" TEXT NOT NULL,
    "zipCode" TEXT NOT NULL,
    "amenities" TEXT[],
    "images" TEXT[],
    "furnishingStatus" "FurnishingStatus",
    "floorNumber" TEXT,
    "totalFloors" INTEGER,
    "facing" "Facing",
    "postedBy" "UserRole" NOT NULL,
    "possessionStatus" "PossessionStatus",
    "tenantsPreferred" "TenantsPreferred",
    "availableFrom" "AvailableFrom",
    "saleType" "SaleType",
    "reraRegistered" BOOLEAN,
    "verified" BOOLEAN NOT NULL DEFAULT false,
    "exclusive" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "userId" TEXT NOT NULL,
    "expectedprice" TEXT,
    "pricenegotiablen" BOOLEAN NOT NULL DEFAULT false,
    "bookingtoken" BOOLEAN DEFAULT false,
    "plotspecialization" TEXT,
    "widthofroadfacing" TEXT,
    "constructiondone" BOOLEAN DEFAULT false,
    "boundrywall" BOOLEAN DEFAULT false,
    "gatedcommunity" BOOLEAN NOT NULL DEFAULT false,
    "approvalauth" "Authority",
    "nooffloorsallowed" INTEGER,
    "noofopenside" INTEGER,
    "plotlenght" INTEGER,
    "plotwidth" INTEGER,
    "ageofconstruction" "AgeofC",
    "amountofbooking" TEXT,
    "mainroadfacing" BOOLEAN DEFAULT false,
    "cafeteria" BOOLEAN DEFAULT false,
    "cornorshowroom" BOOLEAN DEFAULT false,
    "personalwashroom" BOOLEAN DEFAULT false,
    "carpetarea" INTEGER,
    "superarea" INTEGER,
    "areaunit" "AreaUnit",

    CONSTRAINT "Property_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PGDetails" (
    "id" TEXT NOT NULL,
    "propertyId" TEXT NOT NULL,
    "gender" "PGGender" NOT NULL,
    "occupancyType" "OccupancyType" NOT NULL,
    "foodProvided" BOOLEAN NOT NULL,
    "nonVegAllowed" BOOLEAN NOT NULL,
    "selfCooking" BOOLEAN NOT NULL,
    "wifiAvailable" BOOLEAN NOT NULL,
    "acAvailable" BOOLEAN NOT NULL,
    "powerBackup" BOOLEAN NOT NULL,
    "preferredTenants" "PreferredTenants" NOT NULL,

    CONSTRAINT "PGDetails_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CommercialDetails" (
    "id" TEXT NOT NULL,
    "propertyId" TEXT NOT NULL,
    "leaseTerm" INTEGER,
    "securityDeposit" DOUBLE PRECISION,

    CONSTRAINT "CommercialDetails_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Inquiry" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "phone" TEXT NOT NULL,
    "message" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "userId" TEXT NOT NULL,
    "propertyId" TEXT NOT NULL,

    CONSTRAINT "Inquiry_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Service" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "category" "ServiceCategory" NOT NULL,
    "price" DOUBLE PRECISION,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Service_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "BlogPost" (
    "id" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "category" "BlogCategory" NOT NULL,
    "author" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "BlogPost_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "HomeLoan" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "amount" DOUBLE PRECISION NOT NULL,
    "interestRate" DOUBLE PRECISION NOT NULL,
    "term" INTEGER NOT NULL,
    "status" "LoanStatus" NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "HomeLoan_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PropertyValuation" (
    "id" TEXT NOT NULL,
    "propertyId" TEXT NOT NULL,
    "value" DOUBLE PRECISION NOT NULL,
    "date" TIMESTAMP(3) NOT NULL,
    "appraiserName" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "PropertyValuation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Notification" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "type" "NotificationType" NOT NULL,
    "message" TEXT NOT NULL,
    "read" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Notification_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "User_email_key" ON "User"("email");

-- CreateIndex
CREATE UNIQUE INDEX "PGDetails_propertyId_key" ON "PGDetails"("propertyId");

-- CreateIndex
CREATE UNIQUE INDEX "CommercialDetails_propertyId_key" ON "CommercialDetails"("propertyId");

-- AddForeignKey
ALTER TABLE "Property" ADD CONSTRAINT "Property_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PGDetails" ADD CONSTRAINT "PGDetails_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "Property"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommercialDetails" ADD CONSTRAINT "CommercialDetails_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "Property"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Inquiry" ADD CONSTRAINT "Inquiry_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Inquiry" ADD CONSTRAINT "Inquiry_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "Property"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Notification" ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;


/*
  Warnings:

  - Added the required column `createdBy` to the `Service` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "Service" ADD COLUMN     "createdBy" TEXT NOT NULL,
ADD COLUMN     "updatedBy" TEXT,
ADD COLUMN     "verified" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "verifiedAt" TIMESTAMP(3);
-- AlterEnum
ALTER TYPE "UserRole" ADD VALUE 'SERVICE_PROVIDER';

/*
  Warnings:

  - Added the required column `providerId` to the `Service` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "Service" ADD COLUMN     "providerId" TEXT NOT NULL;

-- AddForeignKey
ALTER TABLE "Service" ADD CONSTRAINT "Service_providerId_fkey" FOREIGN KEY ("providerId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AlterTable
ALTER TABLE "Service" ADD COLUMN     "status" TEXT NOT NULL DEFAULT 'PENDING';
