import { DefaultSession, NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { PrismaAdapter } from "@auth/prisma-adapter";
import prisma from "@/lib/prisma";
import bcrypt from "bcryptjs";

// Extend default types for NextAuth
declare module "next-auth" {
  interface User {
    role?: string;
  }
  interface Session {
    user: {
      id: string;
      role?: string;
    } & DefaultSession["user"];
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    role?: string;
    sub?: string; // This ensures that `sub` exists on JWT
  }
}

// NextAuth configuration
export const authOptions: NextAuthOptions = {
  adapter: PrismaAdapter(prisma) as any, // Type assertion to avoid adapter incompatibility

  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "text" },
        password: { label: "Password", type: "password" }
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          return null;
        }

        const user = await prisma.user.findUnique({
          where: {
            email: credentials.email,
          },
        });

        if (!user || !user.password) {
          return null;
        }

        const isPasswordValid = await bcrypt.compare(
          credentials.password,
          user.password
        );

        if (!isPasswordValid) {
          return null;
        }
         console.log(user.role);
        return {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role, // Ensure role is included in the returned user object
        };
      },
    }),
  ],
 
  session: {
    strategy: "jwt", // Use JWT for sessions
  },

  callbacks: {
    async session({ session, token, user }) {
        if (session?.user) {
            session.user.id = token.id as string;
            session.user.role = token.role as string; // Add role to session
        }
        return session;
    },
    async jwt({ token, user }) {
        if (user) {
            token.id = user.id;
            token.role = user.role; // Add role to token
        }
        return token;
    },
},

  pages: {
    signIn: "/auth/signin", // Custom sign-in page
  },
};
