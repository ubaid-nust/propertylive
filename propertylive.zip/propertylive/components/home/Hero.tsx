"use client";
import React from "react";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import bg from "../../public/bg-pic1.svg";
import overlayImg from "../../public/bg-pattern.png";

export function Hero() {
    const router = useRouter();
    return (
        <div className="relative text-white pt-44 pb-40 overflow-hidden">
            <div
                className="absolute inset-0 bg-cover bg-center opacity-50 z-0"
                style={{
                    backgroundImage: `url(${overlayImg.src}), url(${bg.src})`,
                    backgroundPosition: "top, center",
                    backgroundSize: "cover, cover",
                    backgroundRepeat: "no-repeat, no-repeat",
                }}
            />

            <div className="container mx-auto px-4 relative z-10">
                <div className="mb-10 lg:mb-0 flex flex-col items-center">
                    <h2 className="text-2xl text-white font-semibold mb-4 tracking-wider relative after:content-[''] after:absolute after:w-full after:h-0.5 after:bg-cyan after:left-0 after:bottom-[-4px]">
                        Find Your Dream Property
                    </h2>

                    <h1 className="text-center text-4xl md:text-7xl font-bold mb-6 leading-tight">
                        Discover the Perfect <br />
                        Place to Call Home
                    </h1>

                    <p className="text-center text-xl mb-8 text-gray-300 md:w-9/12">
                        Explore your dream living space with us, where comfort
                        meets style, and every home feels like the perfect fit.
                        Let us guide you to the place you've always imagined
                        calling home.
                    </p>

                    <Button
                        onClick={() => router.push("/properties")}
                        className="bg-cyan text-white font-semibold py-4 px-6 rounded-md hover:bg-white hover:text-cyan transition-colors duration-300"
                    >
                        Explore Properties
                    </Button>
                </div>
            </div>
        </div>
    );
}
