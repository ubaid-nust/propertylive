import { useSession } from 'next-auth/react';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';

const AuthButton = () => {
  const { data: session, status } = useSession(); // Get session data and status
  const [mounted, setMounted] = useState(false); // Track whether the component is mounted
  const router = useRouter(); // Call useRouter unconditionally

  // Ensure the component is only rendered after mounting on the client-side
  useEffect(() => {
    setMounted(true);
  }, []);

  // Prevent rendering until the component has mounted and session status is not loading
  if (!mounted || status === 'loading') return null;

  return (
    <button
      className="text-white bg-transparent border-none cursor-pointer hover:text-[#3dd598]"
      onClick={() => router.push(session ? '/profile' : '/auth/signin')}
    >
      {session ? 'Profile' : 'Log In'}
    </button>
  );
};

export default AuthButton;
