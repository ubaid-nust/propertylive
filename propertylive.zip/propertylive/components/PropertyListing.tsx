"use client";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import bgImage from "@/public/17812.jpg";

export default function PropertyIntroCard() {
    const router = useRouter();

    return (
        <div className="box-border m-4 mb-0 block pb-10">
            <Card className="w-full py-6 px-6 relative flex flex-col lg:flex-row items-center lg:items-center space-y-4 lg:space-y-0 lg:space-x-6">
                {/* Text Section */}
                <div className="lg:w-1/2 flex flex-col justify-center space-y-4">
                    <h2 className="text-3xl lg:text-4xl font-bold tracking-tight text-left">
                        Ready to Sell Your Property?
                    </h2>
                    <p className="text-gray-600 text-left max-w-md">
                        Take control of your property listing today. Reach
                        thousands of potential buyers or renters with ease. With
                        just a few clicks, you can list your property and get
                        the exposure it deserves.
                    </p>

                    <CardContent className="text-left">
                        <Button
                            className="py-3 px-6 -ms-6 text-white bg-cyan transition-colors duration-300 flex items-center gap-2"
                            onClick={() =>
                                router.push("/dashboard/properties/new")
                            }
                        >
                            Start Listing Now
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                                strokeWidth="2"
                                stroke="currentColor"
                                className="w-5 h-5 transform rotate-[-45deg]"
                            >
                                <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    d="M5 12h14M12 5l7 7-7 7"
                                />
                            </svg>
                        </Button>
                    </CardContent>
                </div>

                {/* Image Section */}
                <div className="lg:w-1/2 flex justify-center lg:justify-end">
                    <Image
                        src={bgImage}
                        alt="Property illustration"
                        width={550}
                        height={350}
                        className="border border-gray-200 rounded-lg"
                    />
                </div>
            </Card>
        </div>
    );
}
