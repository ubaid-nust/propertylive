"use client";
import React, { useEffect, useState } from "react";
import Image from "next/image";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import {  SquareIcon } from "lucide-react";
import { Property } from "@/types"; // Assuming Property type is defined in your types
import picture from "@/public/dummy-apartment-1.jpg";
import {
  FaBuilding
} from "react-icons/fa";
export function FeaturedProperties() {
    const [properties, setProperties] = useState<Property[]>([]);
    const [error, setError] = useState<string | null>(null);
    const [loading, setLoading] = useState<boolean>(true);

    useEffect(() => {
        const fetchProperties = async () => {
            try {
                const response = await fetch("/api/properties/recent"); // Updated API route
                if (!response.ok) {
                    throw new Error("Failed to fetch properties");
                }
                const data = await response.json();
                setProperties(data);
            } catch (error) {
                setError(
                    error instanceof Error ? error.message : "An error occurred"
                );
            } finally {
                setLoading(false);
            }
        };

        fetchProperties();
    }, []);

    if (loading)
        return (
            <div>
                <h2 className="text-2xl font-bold my-5 mt-10 md:text-4xl text-center text-white">
                    <span className="text-cyan">Newly</span> Listed Properties
                </h2>
                <p className="text-center text-white my-5 text-lg">
                    Loading...
                </p>
                <div className="h-2 bg-white"></div>
            </div>
        );
    if (error) return <div>Error: {error}</div>;

  return (
    <section className="py-12">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-bold mb-16 md:text-4xl text-center text-white"><span className="text-cyan">Newly</span> Listed Properties</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {properties.length > 0 ? (
            properties.map((property) => (
              <Card key={property.id} className="overflow-hidden">
                <div className="relative h-48">
                  <Image
                    src={property.images?.[0] ? `${property.images[0]}` : picture} // Fallback image if property has no image
                    alt={property.title}
                    fill // use 'fill' for the layout
                    style={{ objectFit: 'cover' }} // use style for objectFit
                  />
                </div>
                <CardContent className="p-4">
                  <h3 className="text-lg font-semibold mb-2">{property.title}</h3>
                  <p className="text-2xl font-bold text-blue-600">${property.price.toLocaleString()}</p>
                  <div className="flex justify-between mt-4 text-gray-600">
                    <span className="flex items-center">
                      <FaBuilding className="w-4 h-4 mr-1" /> {property.type}
                    </span>
                    <span className="flex items-center">
                      <FaBuilding className="w-4 h-4 mr-1" /> {property.category}
                    </span>
                    <span className="flex items-center">
                      <SquareIcon className="w-4 h-4 mr-1" /> {property.area} sqft
                    </span>
                  </div>
                </CardContent>
                <CardFooter className="bg-gray-50 p-4">
                  <Button asChild>
                    <Link href={`/dashboard/properties/${property.id}`}>View Details</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))
          ) : (
            <p className="text-center text-gray-500">No properties available at the moment.</p>
          )}
        </div>
      </div>
    </section>
  );
}
