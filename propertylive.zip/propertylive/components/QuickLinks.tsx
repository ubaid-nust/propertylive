import React from "react";
import Link from "next/link";
import { Card, CardContent } from "@/components/ui/card";
import {
    HomeIcon,
    BanknoteIcon,
    ShieldQuestionIcon,
    Sparkles,
    Bug,
    TruckIcon,
    BarChart3Icon,
    ScaleIcon,
} from "lucide-react";

const quickLinks = [
    { name: "Post Free Ad", icon: HomeIcon, href: "/post-ad" },
    { name: "Home Loan", icon: BanknoteIcon, href: "/home-loan" },
    { name: "Advice", icon: ShieldQuestionIcon, href: "/advice" },
    { name: "Home Cleaning", icon: Sparkles, href: "/home-cleaning" },
    { name: "Pest Control", icon: Bug, href: "/pest-control" },
    { name: "Packers and Movers", icon: TruckIcon, href: "/packers-movers" },
    { name: "Property Valuation", icon: BarChart3Icon, href: "/property-valuation" },
    { name: "Legal Services", icon: ScaleIcon, href: "/legal-services" },
];

export function QuickLinks() {
    return (
        <section className="py-16 pt-5 bg-white">
            <div className="container mx-auto px-4">
                <h2 className="text-4xl font-bold tracking-tight mb-4 text-center">
                    <span className="text-cyan">Quick Links</span> for Your Property Needs
                </h2>
                <p className="text-muted-foreground text-center mb-10 max-w-2xl mx-auto">
                    Discover our range of services designed to make your
                    property journey smooth and hassle-free.
                </p>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {quickLinks.map((link) => (
                        <Link key={link.name} href={link.href}>
                            <Card className="h-full transition-all duration-300 hover:shadow-md">
                                <CardContent className="flex flex-col items-center justify-center p-6 h-full">
                                    <div className="mb-4 p-2 rounded-full bg-primary/10">
                                        <link.icon className="w-6 h-6 text-primary" />
                                    </div>
                                    <span className="text-sm font-medium text-center">
                                        {link.name}
                                    </span>
                                </CardContent>
                            </Card>
                        </Link>
                    ))}
                </div>
            </div>
        </section>
    );
}