"use client";

import * as React from "react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";

export default function PropertyFilter() {
    const [filters, setFilters] = React.useState<{
        propertyType: string;
        budget: number[];
        coveredArea: number[];
        postedBy: string;
        postedSince: string;
        availableFrom: string;
        furnishingStatus: string;
        amenities: string[];
        facing: string;
        bathrooms: string;
        floors: number[];
    }>({
        propertyType: "",
        budget: [0, 10000000],
        coveredArea: [0, 10000],
        postedBy: "",
        postedSince: "",
        availableFrom: "",
        furnishingStatus: "",
        amenities: [],
        facing: "",
        bathrooms: "",
        floors: [0, 50],
    });

    const handleCheckboxChange = (amenity: string) => {
        setFilters((prev) => ({
            ...prev,
            amenities: prev.amenities.includes(amenity)
                ? prev.amenities.filter((a) => a !== amenity)
                : [...prev.amenities, amenity],
        }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        
        const transformedFilters = {
            ...filters,
            propertyType: mapPropertyType(filters.propertyType),
            postedBy: filters.postedBy.toUpperCase(), // Assuming postedBy values are already in lowercase
            furnishingStatus: mapFurnishingStatus(filters.furnishingStatus),
            facing: mapFacing(filters.facing),
            availableFrom: mapAvailableFrom(filters.availableFrom),
            amenities: filters.amenities.map(mapAmenity), // Map amenities if needed
        };
        
        console.log("Form Data:", transformedFilters);
        const response = await fetch("/api/properties/filter", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(transformedFilters),
        });

        const data = await response.json();
        console.log("Fetched Properties:", data);
    };

    const mapPropertyType = (value: string) => {
        const propertyTypeMap: { [key: string]: string } = {
            flat: "FLAT",
            house: "HOUSE",
            office: "OFFICE_SPACE",
            coworking: "COMMERCIAL", // Assuming coworking is commercial in your Prisma schema
            shop: "SHOP",
            other: "OTHER",
        };
        return propertyTypeMap[value] || value.toUpperCase();
    };

    const mapFurnishingStatus = (value: string) => {
        const furnishingStatusMap: { [key: string]: string } = {
            furnished: "FURNISHED",
            semiFurnished: "SEMI_FURNISHED",
            unfurnished: "UNFURNISHED",
        };
        return furnishingStatusMap[value] || value.toUpperCase();
    };

    const mapFacing = (value: string) => {
        const facingMap: { [key: string]: string } = {
            east: "EAST",
            west: "WEST",
            north: "NORTH",
            south: "SOUTH",
            northeast: "NORTH_EAST",
            northwest: "NORTH_WEST",
            southeast: "SOUTH_EAST",
            southwest: "SOUTH_WEST",
        };
        return facingMap[value] || value.toUpperCase();
    };

    const mapAvailableFrom = (value: string) => {
        const availableFromMap: { [key: string]: string } = {
            true: "IMMEDIATELY",
            false: "OTHER", // Add mapping for other options if needed
        };
        return availableFromMap[value] || value.toUpperCase();
    };

    const mapAmenity = (amenity: string) => {
        // Optionally, if you need to map amenities to enum values, do so here
        return amenity.toUpperCase(); // Assuming you want to keep amenities in uppercase
    };

    return (
        <div className="w-full bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
                <div className="text-center mb-8">
                    <h2 className="text-2xl font-bold md:text-4xl text-center">
                        Refine Your Property{" "}
                        <span className="text-cyan">Search</span>
                    </h2>
                    <p className="text-muted-foreground text-center mb-10 max-w-2xl mx-auto mt-2">
                        Find the property that fits your needs.
                    </p>
                </div>
                <form
                    onSubmit={handleSubmit}
                    className="bg-white shadow-md rounded-md p-6 space-y-8"
                >
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div className="space-y-1">
                            <Label
                                htmlFor="propertyType"
                                className="text-sm font-semibold text-gray-600"
                            >
                                Property Type
                            </Label>
                            <Select
                                onValueChange={(value) =>
                                    setFilters((prev) => ({
                                        ...prev,
                                        propertyType: value,
                                    }))
                                }
                            >
                                <SelectTrigger
                                    id="propertyType"
                                    className="w-full"
                                >
                                    <SelectValue placeholder="Choose type" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="flat">Flat</SelectItem>
                                    <SelectItem value="house">
                                        House/Villa
                                    </SelectItem>
                                    <SelectItem value="office">
                                        Office Space
                                    </SelectItem>
                                    <SelectItem value="coworking">
                                        Co-Working Space
                                    </SelectItem>
                                    <SelectItem value="shop">
                                        Shop/Showroom
                                    </SelectItem>
                                    <SelectItem value="other">
                                        Other Commercial
                                    </SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="space-y-1">
                            <Label
                                htmlFor="budget"
                                className="text-sm font-semibold text-gray-600"
                            >
                                Budget (in $)
                            </Label>
                            <Slider
                                id="budget"
                                min={0}
                                max={10000000}
                                step={100000}
                                value={filters.budget}
                                onValueChange={(value) =>
                                    setFilters((prev) => ({
                                        ...prev,
                                        budget: value,
                                    }))
                                }
                            />
                            <div className="flex justify-between text-sm text-gray-500">
                                <span>
                                    ${filters.budget[0].toLocaleString()}
                                </span>
                                <span>
                                    ${filters.budget[1].toLocaleString()}
                                </span>
                            </div>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div className="space-y-1">
                            <Label
                                htmlFor="coveredArea"
                                className="text-sm font-semibold text-gray-600"
                            >
                                Covered Area (sq m)
                            </Label>
                            <Slider
                                id="coveredArea"
                                min={0}
                                max={10000}
                                step={100}
                                value={filters.coveredArea}
                                onValueChange={(value) =>
                                    setFilters((prev) => ({
                                        ...prev,
                                        coveredArea: value,
                                    }))
                                }
                            />
                            <div className="flex justify-between text-sm text-gray-500">
                                <span>{filters.coveredArea[0]} sq m</span>
                                <span>{filters.coveredArea[1]} sq m</span>
                            </div>
                        </div>

                        <div className="space-y-1">
                            <Label
                                htmlFor="postedBy"
                                className="text-sm font-semibold text-gray-600"
                            >
                                Posted By
                            </Label>
                            <Select
                                onValueChange={(value) =>
                                    setFilters((prev) => ({
                                        ...prev,
                                        postedBy: value,
                                    }))
                                }
                            >
                                <SelectTrigger id="postedBy" className="w-full">
                                    <SelectValue placeholder="Choose poster" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="agent">Agent</SelectItem>
                                    <SelectItem value="owner">Owner</SelectItem>
                                    <SelectItem value="builder">
                                        Builder
                                    </SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div className="space-y-1">
                            <Label
                                htmlFor="postedSince"
                                className="text-sm font-semibold text-gray-600"
                            >
                                Posted Since
                            </Label>
                            <Select
                                onValueChange={(value) =>
                                    setFilters((prev) => ({
                                        ...prev,
                                        postedSince: value,
                                    }))
                                }
                            >
                                <SelectTrigger
                                    id="postedSince"
                                    className="w-full"
                                >
                                    <SelectValue placeholder="Select" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="anytime">
                                        Anytime
                                    </SelectItem>
                                    <SelectItem value="yesterday">
                                        Yesterday
                                    </SelectItem>
                                    <SelectItem value="last_week">
                                        Last Week
                                    </SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="space-y-1">
                            <Label
                                htmlFor="availableFrom"
                                className="text-sm font-semibold text-gray-600"
                            >
                                Available From
                            </Label>
                            <Select
                                onValueChange={(value) =>
                                    setFilters((prev) => ({
                                        ...prev,
                                        availableFrom: value,
                                    }))
                                }
                            >
                                <SelectTrigger
                                    id="availableFrom"
                                    className="w-full"
                                >
                                    <SelectValue placeholder="Select availability" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="true">
                                        Immediately
                                    </SelectItem>
                                    <SelectItem value="false">Other</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div className="space-y-1">
                            <Label
                                htmlFor="furnishingStatus"
                                className="text-sm font-semibold text-gray-600"
                            >
                                Furnishing Status
                            </Label>
                            <Select
                                onValueChange={(value) =>
                                    setFilters((prev) => ({
                                        ...prev,
                                        furnishingStatus: value,
                                    }))
                                }
                            >
                                <SelectTrigger
                                    id="furnishingStatus"
                                    className="w-full"
                                >
                                    <SelectValue placeholder="Select status" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="furnished">
                                        Furnished
                                    </SelectItem>
                                    <SelectItem value="semiFurnished">
                                        Semi-Furnished
                                    </SelectItem>
                                    <SelectItem value="unfurnished">
                                        Unfurnished
                                    </SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="space-y-1">
                            <Label
                                htmlFor="bathrooms"
                                className="text-sm font-semibold text-gray-600"
                            >
                                Bathrooms
                            </Label>
                            <Select
                                onValueChange={(value) =>
                                    setFilters((prev) => ({
                                        ...prev,
                                        bathrooms: value,
                                    }))
                                }
                            >
                                <SelectTrigger
                                    id="bathrooms"
                                    className="w-full"
                                >
                                    <SelectValue placeholder="Choose number" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="1">1</SelectItem>
                                    <SelectItem value="2">2</SelectItem>
                                    <SelectItem value="3">3</SelectItem>
                                    <SelectItem value="4+">4+</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div className="space-y-1">
                            <Label
                                htmlFor="facing"
                                className="text-sm font-semibold text-gray-600"
                            >
                                Facing
                            </Label>
                            <Select
                                onValueChange={(value) =>
                                    setFilters((prev) => ({
                                        ...prev,
                                        facing: value,
                                    }))
                                }
                            >
                                <SelectTrigger id="facing" className="w-full">
                                    <SelectValue placeholder="Select facing" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="east">East</SelectItem>
                                    <SelectItem value="west">West</SelectItem>
                                    <SelectItem value="north">North</SelectItem>
                                    <SelectItem value="south">South</SelectItem>
                                    <SelectItem value="northwest">
                                        North-West
                                    </SelectItem>
                                    <SelectItem value="northeast">
                                        North-East
                                    </SelectItem>
                                    <SelectItem value="southwest">
                                        South-West
                                    </SelectItem>
                                    <SelectItem value="southeast">
                                        South-East
                                    </SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="space-y-1">
                            <Label
                                htmlFor="floors"
                                className="text-sm font-semibold text-gray-600"
                            >
                                Floors (Range)
                            </Label>
                            <Slider
                                id="floors"
                                min={0}
                                max={50}
                                step={1}
                                value={filters.floors}
                                onValueChange={(value) =>
                                    setFilters((prev) => ({
                                        ...prev,
                                        floors: value,
                                    }))
                                }
                            />
                            <div className="flex justify-between text-sm text-gray-500">
                                <span>{filters.floors[0]}</span>
                                <span>{filters.floors[1]}</span>
                            </div>
                        </div>
                    </div>

                    <div className="space-y-1">
                        <Label className="text-sm font-semibold text-gray-600">
                            Amenities
                        </Label>
                        <div className="grid grid-cols-2 gap-4">
                            {[
                                "Waste Disposal",
                                "Park",
                                "Rainwater Harvesting",
                                "Water Storage",
                                "Indoor Games Room",
                                "Security",
                                "Gym",
                                "Kids Play Area",
                                "Power Backup",
                                "Reserved Parking",
                                "Swimming Pool",
                                "Multi-purpose Courts",
                                "Lift",
                                "Clubhouse",
                            ].map((amenity) => (
                                <div
                                    key={amenity}
                                    className="flex items-center"
                                >
                                    <Checkbox
                                        id={amenity}
                                        checked={filters.amenities.includes(
                                            amenity
                                        )}
                                        onCheckedChange={() =>
                                            handleCheckboxChange(amenity)
                                        }
                                    />
                                    <label
                                        htmlFor={amenity}
                                        className="ml-2 text-sm text-gray-600"
                                    >
                                        {amenity}
                                    </label>
                                </div>
                            ))}
                        </div>
                    </div>

                    <Button
                        type="submit"
                        className="w-full py-2 text-white bg-gray-900 rounded-md hover:bg-gray-700"
                    >
                        Apply Filters
                    </Button>
                </form>
            </div>
        </div>
    );
}
