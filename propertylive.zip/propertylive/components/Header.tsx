"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import { useSession, signOut } from "next-auth/react";
import {
    Popover,
    PopoverTrigger,
    PopoverContent,
} from "@/components/ui/popover";

const NavLink = ({
    href,
    children,
    onClick,
    className,
}: {
    href: string;
    children: React.ReactNode;
    onClick?: () => void;
    className?: string;
}) => (
    <Link
        href={href}
        className={`text-white hover:text-[#3dd598] transition-colors ${className}`}
        onClick={onClick}
    >
        {children}
    </Link>
);

const MenuIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
    >
        <line x1="4" x2="20" y1="12" y2="12" />
        <line x1="4" x2="20" y1="6" y2="6" />
        <line x1="4" x2="20" y1="18" y2="18" />
    </svg>
);

const CloseIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
    >
        <line x1="18" y1="6" x2="6" y2="18" />
        <line x1="6" y1="6" x2="18" y2="18" />
    </svg>
);

const Navbar: React.FC = () => {
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const [scrollY, setScrollY] = useState(0);
    const [isAtTop, setIsAtTop] = useState(true);

    const toggleMobileMenu = () => {
        setIsMobileMenuOpen(!isMobileMenuOpen);
    };

    const closeMobileMenu = () => {
        setIsMobileMenuOpen(false);
    };

    const handleScroll = () => {
        const scrollPosition = window.scrollY;
        setScrollY(scrollPosition);
        setIsAtTop(scrollPosition === 0); // Check if we are at the top of the page
    };

    useEffect(() => {
        window.addEventListener("scroll", handleScroll);
        return () => {
            window.removeEventListener("scroll", handleScroll);
        };
    }, []);

    const router = useRouter();
    const { data: session, status } = useSession();

    return (
        <nav
            className={`fixed md:px-4 top-0 left-0 z-50 w-full bg-black transition-all duration-300 ${
                isAtTop ? "md:py-8" : "md:py-3"
            }`}
        >
            <div className="container md:mx-auto flex md:items-center justify-between">
                <Link href="/" className="text-white text-2xl font-bold">
                    Property Live
                </Link>
                <div className="hidden md:flex space-x-6">
                    <Link
                        href="/properties"
                        className="text-white text-sm font-medium hover:text-[#3dd598]"
                    >
                        Rental Services
                    </Link>
                    <Link
                        href="/properties"
                        className="text-white text-sm font-medium hover:text-[#3dd598]"
                    >
                        Buy/Sell Services
                    </Link>
                    <Link
                        href="/home-services"
                        className="text-white text-sm font-medium hover:text-[#3dd598]"
                    >
                        Home Services
                    </Link>
                    <Popover>
                        <PopoverTrigger className="text-white text-sm font-medium hover:text-[#3dd598]">
                            Advice Corner
                        </PopoverTrigger>
                        <PopoverContent>
                            <ul>
                                {/* Map over adviceCorner */}
                            </ul>
                        </PopoverContent>
                    </Popover>
                    <NavLink
                        href="/sales-inquiry"
                        className="text-sm font-medium text-black"
                    >
                        Sales Inquiry
                    </NavLink>
                </div>
                <div className="hidden md:flex items-center space-x-4">
                    {status === "unauthenticated" && (
                        <>
                            <Button
                                className="bg-[#3dd598] text-white hover:bg-[#2ac085]"
                                onClick={() => router.push("/auth/register")}
                            >
                                Sign Up
                            </Button>
                            <Button
                                variant="ghost"
                                className="bg-[#3dd598] text-white hover:bg-[#2ac085]"
                                onClick={() => router.push("/auth/signin")}
                            >
                                Log In
                            </Button>
                        </>
                    )}
                    {status === "authenticated" && (
                        <>
                            <Button
                                className="bg-[#3dd598] text-white hover:bg-[#2ac085]"
                                onClick={() => router.push("/profile")}
                            >
                                Profile
                            </Button>
                            <Button
                                variant="ghost"
                                className="bg-[#3dd598] text-white hover:bg-[#2ac085]"
                                onClick={() => signOut()}
                            >
                                Sign Out
                            </Button>
                        </>
                    )}
                    {session?.user.role === "ADMIN" && (
                        <Button
                            variant="ghost"
                            className="bg-[#3dd598] text-white hover:bg-[#2ac085]"
                            onClick={() => router.push("/dashboard/adminpannel")}
                        >
                            Admin Panel
                        </Button>
                    )}
                </div>
                <Button
                    variant="ghost"
                    className="md:hidden text-white p-0"
                    onClick={toggleMobileMenu}
                >
                    {isMobileMenuOpen ? (
                        <CloseIcon className="h-6 w-6" />
                    ) : (
                        <MenuIcon className="h-6 w-6" />
                    )}
                </Button>
            </div>

            {isMobileMenuOpen && (
                <div className="md:hidden mt-8 space-y-4 bg-[#191818e3] font-bold text-white w-full p-2 absolute top-2 left-0 z-40 backdrop-blur-md">
                    <div className="flex flex-col space-y-4">
                        <Link
                            href="/properties"
                            className="text-white text-sm font-medium hover:text-[#3dd598]"
                        >
                            Rental Services
                        </Link>
                        <Link
                            href="/properties"
                            className="text-white text-sm font-medium hover:text-[#3dd598]"
                        >
                            Buy/Sell Services
                        </Link>
                        <Link
                            href="/properties"
                            className="text-white text-sm font-medium hover:text-[#3dd598]"
                        >
                            Home Services
                        </Link>
                    </div>
                    <NavLink
                        href="/sales-inquiry"
                        onClick={closeMobileMenu}
                        className="block py-2 text-sm font-medium"
                    >
                        Sales Inquiry
                    </NavLink>
                    <div className="flex flex-col space-y-2">
                        {status === "unauthenticated" && (
                            <>
                                <Button
                                    className="bg-[#3dd598] text-white hover:bg-[#2ac085]"
                                    onClick={() => router.push("/auth/register")}
                                >
                                    Sign Up
                                </Button>
                                <Button
                                    variant="ghost"
                                    className="bg-[#3dd598] text-white hover:bg-[#2ac085]"
                                    onClick={() => router.push("/auth/signin")}
                                >
                                    Log In
                                </Button>
                            </>
                        )}
                        {status === "authenticated" && (
                            <>
                                <Button
                                    className="bg-[#3dd598] text-white hover:bg-[#2ac085]"
                                    onClick={() => router.push("/profile")}
                                >
                                    Profile
                                </Button>
                                <Button
                                    variant="ghost"
                                    className="bg-[#3dd598] text-white hover:bg-[#2ac085]"
                                    onClick={() => signOut()}
                                >
                                    Sign Out
                                </Button>
                            </>
                        )}
                        {session?.user.role === "ADMIN" && (
                            <Button
                                variant="ghost"
                                className="bg-[#3dd598] text-white hover:bg-[#2ac085]"
                                onClick={() =>
                                    router.push("/dashboard/adminpannel")
                                }
                            >
                                Admin Panel
                            </Button>
                        )}
                    </div>
                </div>
            )}
        </nav>
    );
};

export default Navbar;
