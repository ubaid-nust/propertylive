// components/Footer.tsx
import React from 'react';
import Link from 'next/link';
import { FacebookIcon, TwitterIcon, InstagramIcon, LinkedinIcon } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-neutral-900 text-white py-12 border-t-2 border-cyan">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">About Us</h3>
            <p className="text-gray-400">PropertyLive is your trusted partner in finding the perfect property. Whether you're buying, selling, or renting, we've got you covered.</p>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link href="/buy" className="text-gray-400 hover:text-white">Buy Property</Link></li>
              <li><Link href="/rent" className="text-gray-400 hover:text-white">Rent Property</Link></li>
              <li><Link href="/sell" className="text-gray-400 hover:text-white">Sell Property</Link></li>
              <li><Link href="/home-loans" className="text-gray-400 hover:text-white">Home Loans</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <p className="text-gray-400">123 Property Street</p>
            <p className="text-gray-400">Real Estate City, RE 12345</p>
            <p className="text-gray-400">Phone: (123) 456-7890</p>
            <p className="text-gray-400">Email: info@propertylive.com</p>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Follow Us</h3>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white"><FacebookIcon /></a>
              <a href="#" className="text-gray-400 hover:text-white"><TwitterIcon /></a>
              <a href="#" className="text-gray-400 hover:text-white"><InstagramIcon /></a>
              <a href="#" className="text-gray-400 hover:text-white"><LinkedinIcon /></a>
            </div>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-gray-700 text-center text-gray-400">
          <p>&copy; 2024 PropertyLive. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}