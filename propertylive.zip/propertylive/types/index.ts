// types/index.ts
import { Prisma } from '@prisma/client';

// Use Prisma's generated types
export type Property = Prisma.PropertyGetPayload<{
  include: { user: true }
}>;

export type User = Prisma.UserGetPayload<{}>;

// Extend the built-in Session type from next-auth
import { Session as NextAuthSession } from 'next-auth';

export interface Session extends NextAuthSession {
  user: User & { id: string }; // Ensure id is always present
}

// Re-export enums from Prisma
export { Prisma };