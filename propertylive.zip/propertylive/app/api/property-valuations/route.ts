// app/api/property-valuations/route.ts

import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import prisma from '@/lib/prisma';

export async function GET(request: Request) {
  const session = await getServerSession();
  
  if (!session || !session.user || !session.user.email) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const { searchParams } = new URL(request.url);
  const propertyId = searchParams.get('propertyId');
  
  if (!propertyId) {
    return NextResponse.json({ error: 'Property ID is required' }, { status: 400 });
  }

  try {
    const valuations = await prisma.propertyValuation.findMany({
      where: { propertyId },
      orderBy: { date: 'desc' },
    });

    return NextResponse.json(valuations);
  } catch (error) {
    console.error('Failed to fetch property valuations:', error);
    return NextResponse.json({ error: 'Failed to fetch property valuations' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const session = await getServerSession();
  
  if (!session || !session.user || !session.user.email) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const body = await request.json();
    const { propertyId, value, appraiserName } = body;

    if (!propertyId || !value || !appraiserName) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    const valuation = await prisma.propertyValuation.create({
      data: {
        propertyId,
        value,
        appraiserName,
        date: new Date(),
      },
    });

    return NextResponse.json(valuation, { status: 201 });
  } catch (error) {
    console.error('Failed to create property valuation:', error);
    return NextResponse.json({ error: 'Failed to create property valuation' }, { status: 500 });
  }
}