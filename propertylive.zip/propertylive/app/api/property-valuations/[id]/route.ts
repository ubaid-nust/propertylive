// app/api/property-valuations/[id]/route.ts

import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import prisma from '@/lib/prisma';

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession();
  
  if (!session || !session.user || !session.user.email) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const valuation = await prisma.propertyValuation.findUnique({
      where: { id: params.id },
    });

    if (!valuation) {
      return NextResponse.json({ error: 'Property valuation not found' }, { status: 404 });
    }

    return NextResponse.json(valuation);
  } catch (error) {
    console.error('Failed to fetch property valuation:', error);
    return NextResponse.json({ error: 'Failed to fetch property valuation' }, { status: 500 });
  }
}

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession();
  
  if (!session || !session.user || !session.user.email) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const body = await request.json();
    const { value, appraiserName } = body;

    if (!value || !appraiserName) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    const updatedValuation = await prisma.propertyValuation.update({
      where: { id: params.id },
      data: {
        value,
        appraiserName,
        date: new Date(),
      },
    });

    return NextResponse.json(updatedValuation);
  } catch (error) {
    console.error('Failed to update property valuation:', error);
    return NextResponse.json({ error: 'Failed to update property valuation' }, { status: 500 });
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession();
  
  if (!session || !session.user || !session.user.email) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    await prisma.propertyValuation.delete({
      where: { id: params.id },
    });

    return NextResponse.json({ message: 'Property valuation deleted successfully' });
  } catch (error) {
    console.error('Failed to delete property valuation:', error);
    return NextResponse.json({ error: 'Failed to delete property valuation' }, { status: 500 });
  }
}