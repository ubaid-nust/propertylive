import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";

export async function PUT(request: Request, { params }: { params: { id: string } }) {
    const { id } = params;

    try {
        await prisma.service.update({
            where: { id },
            data: { status: "APPROVED" },
        });

        return NextResponse.json({ message: "Service approved successfully" });
    } catch (error) {
        console.error("Error approving service:", error);
        return NextResponse.json({ error: "Failed to approve service" }, { status: 500 });
    }
}