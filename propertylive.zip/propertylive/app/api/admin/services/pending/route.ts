import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";

export async function GET() {
    try {
        const pendingServices = await prisma.service.findMany({
            where: { status: "PENDING" },
            include: {
                provider: {
                    select: {
                        name: true,
                        email: true,
                        role: true,
                    },
                },
            },
        });

        return NextResponse.json(pendingServices);
    } catch (error) {
        console.error("Error fetching pending services:", error);
        return NextResponse.json({ error: "Failed to fetch pending services" }, { status: 500 });
    }
}
