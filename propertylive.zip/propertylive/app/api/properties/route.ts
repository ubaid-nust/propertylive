import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import prisma from '@/lib/prisma';
import { authOptions } from '@/lib/auth';
import cloudinary from '@/lib/cloudinary'; // Import Cloudinary configuration

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const page = parseInt(searchParams.get("page") || "1");
  const limit = parseInt(searchParams.get("limit") || "10");
  const skip = (page - 1) * limit;

  try {
    const properties = await prisma.property.findMany({
      skip,
      take: limit,
      include: { user: true },
    });
    const total = await prisma.property.count();

    return NextResponse.json({
      properties,
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
    });
  } catch (error) {
    console.error("Failed to fetch properties:", error);
    return NextResponse.json(
      { error: "Failed to fetch properties" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  const session = await getServerSession(authOptions);

  if (!session || !session.user || !session.user.email) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const formData = await request.formData();
  console.log(formData);
  
  try {
    const propertyData: any = {};
    const imageFiles: File[] = [];

    for (const [key, value] of formData.entries()) {
      if (key === 'imagesfile') {
        if (value instanceof File) {
          imageFiles.push(value);
        }
      } else if (key === 'amenities' || key === 'images') {
        // Handle arrays
        if (!propertyData[key]) {
          propertyData[key] = [];
        }
        propertyData[key].push(value);
      } else {
        // Handle other fields
        propertyData[key] = value;
      }
    }

    // Convert numeric fields
    ['price', 'bedrooms', 'bathrooms', 'area', 'totalFloors', 'balcony', 'nooffloorsallowed', 'noofopenside', 'carpetarea', 'superarea', 'plotwidth', 'plotlenght' ].forEach(field => {
      if (field in propertyData) {
        propertyData[field] = Number(propertyData[field]);
      }
    });

    // Convert boolean fields
    ['verified', 'exclusive', 'pricenegotiablen', 'bookingtoken', 'constructiondone', 'boundrywall', 'gatedcommunity', 'mainroadfacing', 'cafeteria', 'cornorshowroom', 'personalwashroom'].forEach(field => {
      if (field in propertyData) {
        propertyData[field] = propertyData[field] === 'true';
      }
    });

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
      select: { id: true, role: true }
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Handle Cloudinary file uploads
    const imagePaths: string[] = [];
    
    for (const file of imageFiles) {
      const buffer = await file.arrayBuffer();
      const base64Str = Buffer.from(buffer).toString('base64');
      const dataUri = `data:${file.type};base64,${base64Str}`;

      const uploadResponse = await cloudinary.uploader.upload(dataUri, {
        folder: 'PropertyImages', // Optional: Organize uploads in a folder
        use_filename: true,
        unique_filename: false,
        resource_type: 'image'
      });

      imagePaths.push(uploadResponse.secure_url);
    }

    // Create property in the database
    const property = await prisma.property.create({
      data: {
        ...propertyData,
        user: { connect: { id: user.id } },
        postedBy: user.role,
        images: imagePaths, // Store Cloudinary URLs
      },
    });

    return NextResponse.json(property, { status: 201 });
  } catch (error) {
    console.error('Failed to create property:', error);
    return NextResponse.json({ error: 'Failed to create property' }, { status: 500 });
  }
}
