import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";

export async function POST(request: Request) {
  try {
    const filters = await request.json();

    console.log("Filters:", filters);

    const properties = await prisma.property.findMany({
      where: {
        type: filters.propertyType || undefined,
        price: {
          gte: filters.budget[0],
          lte: filters.budget[1],
        },
        area: {
          gte: filters.coveredArea[0],
          lte: filters.coveredArea[1],
        },
        // postedBy: filters.postedBy || undefined,
        // createdAt: filters.postedSince ? { gte: filters.postedSince } : undefined,
        // availableFrom: filters.availableFrom ? { equals: filters.availableFrom } : undefined, // Enum handling
        // furnishingStatus: filters.furnishingStatus || undefined,
        // amenities: {
        //   hasEvery: filters.amenities.length > 0 ? filters.amenities : undefined,
        // },
        facing: filters.facing || undefined,
        bathrooms: filters.bathrooms || undefined,
        totalFloors: {
          gte: filters.floors[0],
          lte: filters.floors[1],
        },
      },
    });
    
    

    return NextResponse.json(properties);
  } catch (error) {
    console.error("Failed to fetch properties:", error);
    return NextResponse.json({ error: "Failed to fetch properties" }, { status: 500 });
  }
}