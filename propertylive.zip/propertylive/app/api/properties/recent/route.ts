import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function GET() {
  try {
    const recentProperties = await prisma.property.findMany({
      orderBy: {
        createdAt: 'desc',
      },
      take: 4, // Limit to 4 properties
    });

    return NextResponse.json(recentProperties);
  } catch (error) {
    console.error('Error fetching recent properties:', error);
    return NextResponse.json({ error: 'Failed to fetch properties' }, { status: 500 });
  }
}