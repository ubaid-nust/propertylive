// app/api/properties/[id]/route.ts

import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import prisma from '@/lib/prisma';
import { authOptions } from '@/lib/auth';

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const property = await prisma.property.findUnique({
      where: { id: params.id },
      include: { user: true },
    });

    if (!property) {
      return NextResponse.json({ error: 'Property not found' }, { status: 404 });
    }

    return NextResponse.json(property);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch property' }, { status: 500 });
  }
}


export async function PUT(request: Request, { params }: { params: { id: string } }) {

  // Parse the JSON request body only once
  const body = await request.json();
  console.log(body);
  // Get session to check if the user is authorized
  const session = await getServerSession();
  if (!session || !session.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    // Update the property in the database using the body data
    const property = await prisma.property.update({
      where: { id: params.id },
      data: body, // Use the parsed body data for the update
    });

    // Return the updated property data as a JSON response
    return NextResponse.json(property);
  } catch (error) {
    console.error('Error updating property:', error);
    return NextResponse.json({ error: 'Failed to update property' }, { status: 500 });
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session || !session.user || !session.user.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const property = await prisma.property.findUnique({
      where: { id: params.id },
      select: { userId: true },
    });

    if (!property) {
      return NextResponse.json({ error: 'Property not found' }, { status: 404 });
    }

    if (property.userId !== session.user.id) {
      return NextResponse.json({ error: 'Forbidden - You do not own this property' }, { status: 403 });
    }

    // Delete associated inquiries first
    await prisma.inquiry.deleteMany({
      where: { propertyId: params.id },
    });

    // Now delete the property
    await prisma.property.delete({
      where: { id: params.id },
    });

    return NextResponse.json({ message: 'Property and associated inquiries deleted successfully' });
  } catch (error) {
    console.error('Error deleting property:', error);
    return NextResponse.json({ error: 'Failed to delete property' }, { status: 500 });
  }
}