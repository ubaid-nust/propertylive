import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import prisma from '@/lib/prisma';
import { Prisma, ServiceCategory } from '@prisma/client';
import { authOptions } from '@/lib/auth';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const page = parseInt(searchParams.get('page') || '1');
  const limit = parseInt(searchParams.get('limit') || '10');
  const category = searchParams.get('category');
  const skip = (page - 1) * limit;

  try {
    const whereClause: Prisma.ServiceWhereInput = { verified: true }; // Only fetch verified services
    if (category) {
      whereClause.category = category as ServiceCategory;
    }

    const services = await prisma.service.findMany({
      where: whereClause,
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' },
    });
    const total = await prisma.service.count({ where: whereClause });

    return NextResponse.json({
      services,
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
    });
  } catch (error) {
    console.error('Failed to fetch services:', error);
    return NextResponse.json({ error: 'Failed to fetch services' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const session = await getServerSession(authOptions);

  if (
    !session ||
    !session.user?.role ||
    !['SERVICE_PROVIDER', 'BUILDER', 'AGENT', 'OWNER'].includes(session.user.role)
  ) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const body = await request.json();
    const { name, description, category, price } = body;

    // Validate required fields
    if (!name || !description || !category) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Create service with the logged-in user's ID as the provider
    const service = await prisma.service.create({
      data: {
        name,
        description,
        category: category as ServiceCategory,
        price,
        verified: false, // Initially unverified, pending admin review
        status: 'PENDING', // Set status to PENDING
        providerId: session.user.id, // Associate with the logged-in user
        createdBy: session.user.id,
      },
    });

    return NextResponse.json(service, { status: 201 });
  } catch (error) {
    console.error('Failed to create service:', error);
    return NextResponse.json({ error: 'Failed to create service' }, { status: 500 });
  }
}
