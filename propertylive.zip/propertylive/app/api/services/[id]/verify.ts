// app/api/services/[id]/verify.ts

import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function PUT(req: Request, { params }: { params: { id: string } }) {
  const { id } = params;

  try {
    const body = await req.json();
    const { verified } = body;

    // Ensure the 'verified' field is a boolean value
    if (typeof verified !== 'boolean') {
      return NextResponse.json({ error: 'Invalid value for "verified"' }, { status: 400 });
    }

    const updatedService = await prisma.service.update({
      where: { id },
      data: {
        verified,
        verifiedAt: verified ? new Date() : null,
      },
    });

    return NextResponse.json(updatedService);
  } catch (error) {
    return NextResponse.json({ error }, { status: 500 });
  }
}
