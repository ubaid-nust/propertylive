import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import prisma from "@/lib/prisma";
import { UserRole } from "@prisma/client";
import cloudinary from "@/lib/cloudinary";

interface RegistrationData {
    name: string;
    email: string;
    password: string;
    phone: string;
    role: string;
    services: string[]; // Added to handle services
}

export async function POST(req: Request) {
    try {
        // Parse the form data using req.formData()
        const formData = await req.formData();

        const name = formData.get("name") as string;
        const email = formData.get("email") as string;
        const password = formData.get("password") as string;
        const role = formData.get("role") as string;
        const phone = formData.get("phone") as string;
        const imageFile = formData.get("image") as File | null;
        const services = JSON.parse(formData.get("services") as string) as string[]; // Parse selected services

        // Basic validation
        if (!name || !email || !password || !role || !phone || !imageFile) {
            return NextResponse.json(
                { error: "Missing required fields" },
                { status: 400 }
            );
        }

        // Validate the role
        if (!["BUILDER", "AGENT", "OWNER", "SERVICE_PROVIDER", "USER"].includes(role.toUpperCase())) {
            return NextResponse.json(
                { error: "Invalid role" },
                { status: 400 }
            );
        }

        // Check if the user already exists
        const existingUser = await prisma.user.findUnique({
            where: { email },
        });

        if (existingUser) {
            return NextResponse.json(
                { error: "User already exists" },
                { status: 400 }
            );
        }

        // Hash the password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Convert the role to the UserRole enum type
        const userRole = role.toUpperCase() as UserRole;

        // Handle Cloudinary image upload
        const buffer = await imageFile.arrayBuffer();
        const base64Str = Buffer.from(buffer).toString("base64");
        const dataUri = `data:${imageFile.type};base64,${base64Str}`;

        const uploadResponse = await cloudinary.uploader.upload(dataUri, {
            folder: "UserProfilePictures",
            use_filename: true,
            unique_filename: false,
            resource_type: "image",
        });

        // Create the user
        const user = await prisma.user.create({
            data: {
                name,
                email,
                password: hashedPassword,
                phone,
                role: userRole,
                image: uploadResponse.secure_url,
            },
        });

        // Store services only for roles other than "USER"
        if (userRole !== "USER" && services.length > 0) {
            const serviceData = services.map((service) => ({
                name: service,
                description: null, // Assuming description is optional
                category: null, // Assuming category is optional
                status: "PENDING",
                providerId: user.id,
                createdBy: null, // Assuming createdBy is optional
            }));
        
            await prisma.service.createMany({
                data: serviceData,
            });
        }
        

        return NextResponse.json(
            { message: "User created successfully", userId: user.id },
            { status: 201 }
        );
    } catch (error) {
        console.error("Registration error:", error);
        return NextResponse.json(
            { error: "Internal Server Error" },
            { status: 500 }
        );
    }
}
