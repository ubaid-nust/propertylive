// app/api/home-loans/route.ts

import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import prisma from '@/lib/prisma';
import { Prisma } from '@prisma/client';

export async function GET(request: Request) {
  const session = await getServerSession();
  
  if (!session || !session.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const { searchParams } = new URL(request.url);
  const page = parseInt(searchParams.get('page') || '1');
  const limit = parseInt(searchParams.get('limit') || '10');
  const skip = (page - 1) * limit;

  try {
    const homeLoans = await prisma.homeLoan.findMany({
      where: { userId: session.user.id },
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' },
    });
    const total = await prisma.homeLoan.count({ where: { userId: session.user.id } });

    return NextResponse.json({
      homeLoans,
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
    });
  } catch (error) {
    console.error('Failed to fetch home loans:', error);
    return NextResponse.json({ error: 'Failed to fetch home loans' }, { status: 500 });
  }
}


export async function POST(request: Request) {
    const session = await getServerSession();
    
    if (!session || !session.user || !session.user.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
  
    try {
      const body = await request.json();
  
      // Validate required fields
      const requiredFields = ['amount', 'interestRate', 'term'];
      for (const field of requiredFields) {
        if (!(field in body)) {
          return NextResponse.json({ error: `Missing required field: ${field}` }, { status: 400 });
        }
      }
  
      // Find the user by email
      const user = await prisma.user.findUnique({
        where: { email: session.user.email },
      });
  
      if (!user) {
        return NextResponse.json({ error: 'User not found' }, { status: 404 });
      }
  
      // Create the home loan
      const homeLoan = await prisma.homeLoan.create({
        data: {
          amount: body.amount,
          interestRate: body.interestRate,
          term: body.term,
          status: 'PENDING',
          userId: user.id, // Directly provide userId instead of nested user object
        },
      });
  
      return NextResponse.json(homeLoan, { status: 201 });
    } catch (error) {
      console.error('Failed to create home loan:', error);
      if (error instanceof Prisma.PrismaClientKnownRequestError) {
        return NextResponse.json({ error: error.message }, { status: 400 });
      }
      return NextResponse.json({ error: 'Failed to create home loan' }, { status: 500 });
    }
  }