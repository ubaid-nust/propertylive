// app/api/home-loans/[id]/route.ts

import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import prisma from '@/lib/prisma';

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession();
  
  if (!session || !session.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const homeLoan = await prisma.homeLoan.findUnique({
      where: { id: params.id },
    });

    if (!homeLoan) {
      return NextResponse.json({ error: 'Home loan not found' }, { status: 404 });
    }

    if (homeLoan.userId !== session.user.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    return NextResponse.json(homeLoan);
  } catch (error) {
    console.error('Failed to fetch home loan:', error);
    return NextResponse.json({ error: 'Failed to fetch home loan' }, { status: 500 });
  }
}

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession();
  
  if (!session || !session.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const body = await request.json();
    const { amount, interestRate, term, status } = body;

    const homeLoan = await prisma.homeLoan.findUnique({
      where: { id: params.id },
    });

    if (!homeLoan) {
      return NextResponse.json({ error: 'Home loan not found' }, { status: 404 });
    }

    if (homeLoan.userId !== session.user.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const updatedHomeLoan = await prisma.homeLoan.update({
      where: { id: params.id },
      data: {
        amount,
        interestRate,
        term,
        status,
      },
    });

    return NextResponse.json(updatedHomeLoan);
  } catch (error) {
    console.error('Failed to update home loan:', error);
    return NextResponse.json({ error: 'Failed to update home loan' }, { status: 500 });
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession();
  
  if (!session || !session.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const homeLoan = await prisma.homeLoan.findUnique({
      where: { id: params.id },
    });

    if (!homeLoan) {
      return NextResponse.json({ error: 'Home loan not found' }, { status: 404 });
    }

    if (homeLoan.userId !== session.user.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    await prisma.homeLoan.delete({
      where: { id: params.id },
    });

    return NextResponse.json({ message: 'Home loan deleted successfully' });
  } catch (error) {
    console.error('Failed to delete home loan:', error);
    return NextResponse.json({ error: 'Failed to delete home loan' }, { status: 500 });
  }
}
