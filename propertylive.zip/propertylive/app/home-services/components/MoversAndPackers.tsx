const MoversAndPackers = () => {
    return (
      <section className="bg-gray-100 p-4 rounded-lg shadow-md mb-4">
        <h2 className="text-xl font-semibold text-[#1D3557] mb-2">
          Movers and Packers
        </h2>
        <p className="text-gray-600">
          We offer professional moving and packing services to make your
          relocation stress-free.
        </p>
      </section>
    );
  };
  
  export default MoversAndPackers;
  