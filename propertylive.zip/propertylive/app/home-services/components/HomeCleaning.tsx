const HomeCleaning = () => {
    return (
      <section className="bg-gray-100 p-4 rounded-lg shadow-md mb-4">
        <h2 className="text-xl font-semibold text-[#1D3557] mb-2">
          Home Cleaning
        </h2>
        <p className="text-gray-600">
          Our expert home cleaning services ensure a spotless and healthy home
          environment.
        </p>
      </section>
    );
  };
  
  export default HomeCleaning;
  