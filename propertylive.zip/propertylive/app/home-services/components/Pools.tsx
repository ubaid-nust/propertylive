const Pools = () => {
    return (
      <section className="bg-gray-100 p-4 rounded-lg shadow-md mb-4">
        <h2 className="text-xl font-semibold text-[#1D3557] mb-2">Pools</h2>
        <ul className="list-disc list-inside text-gray-600">
          <li>Electricians</li>
          <li>Plumbers</li>
          <li>Tilers</li>
          <li>Bricklayers</li>
        </ul>
      </section>
    );
  };
  
  export default Pools;
  