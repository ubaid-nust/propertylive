import MoversAndPackers from "./components/MoversAndPackers";
import HomeCleaning from "./components/HomeCleaning";
import Pools from "./components/Pools";
import Technicians from "./components/Technicians";


const HomeServices = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-[#1D3557] text-white py-4">
        <h1 className="text-2xl font-semibold text-center">Home Services</h1>
      </header>
      <main className="container mx-auto px-4 py-8">
        <MoversAndPackers />
        <HomeCleaning />
        <Pools />
        <Technicians />
      </main>
    </div>
  );
};

export default HomeServices;
