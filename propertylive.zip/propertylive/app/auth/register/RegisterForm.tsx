"use client";

import React, { useState, FormEvent } from "react";
import { useRouter } from "next/navigation";
import { signIn } from "next-auth/react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea"; // Import for description input
import bg from "@/public/bg-pic1.svg";
import Link from "next/link";

import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";

const servicesByRole: Record<string, string[]> = {
    builder: ["Selling a House", "Giving House on Rent"],
    agent: ["Selling a House", "Giving House on Rent"],
    owner: ["Selling a House", "Giving House on Rent"],
    service_provider: [
        "Home Cleaning",
        "Pest Control",
        "Landscaping",
        "Electricians",
        "Plumbers",
        "Property Valuation",
    ],
};

interface FormData {
    name: string;
    email: string;
    password: string;
    role: string;
    image: File | null;
    phone: string;
    services: {
        name: string;
        description: string;
        category: string;
    }[];
}

const RegisterForm: React.FC = () => {
    const [formData, setFormData] = useState<FormData>({
        name: "",
        email: "",
        password: "",
        role: "user",
        image: null,
        phone: "",
        services: [],
    });
    const [error, setError] = useState<string>("");
    const [loading, setLoading] = useState<boolean>(false);
    const [newService, setNewService] = useState({
        name: "",
        description: "",
        category: "",
    });
    const router = useRouter();

    const handleChange = (
        e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
    ) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
    };

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0] || null;
        setFormData((prev) => ({ ...prev, image: file }));
    };

    const handleNewServiceChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setNewService((prev) => ({ ...prev, [name]: value }));
    };

    const addService = () => {
        if (newService.name) {
            setFormData((prev) => ({
                ...prev,
                services: [...prev.services, newService],
            }));
            setNewService({ name: "", description: "", category: "" }); // Reset service input
        }
    };

    const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setError("");
        setLoading(true);

        try {
            const formDataToSend = new FormData();
            formDataToSend.append("name", formData.name);
            formDataToSend.append("email", formData.email);
            formDataToSend.append("password", formData.password);
            formDataToSend.append("role", formData.role);
            formDataToSend.append("phone", formData.phone);
            if (formData.image) {
                formDataToSend.append("image", formData.image);
            }
            formDataToSend.append("services", JSON.stringify(formData.services));

            const response = await fetch("/api/auth/register", {
                method: "POST",
                body: formDataToSend,
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || "Registration failed");
            }

            const result = await signIn("credentials", {
                email: formData.email,
                password: formData.password,
                redirect: false,
            });

            if (result?.error) {
                throw new Error(result.error);
            }

            router.push("/");
        } catch (error) {
            if (error instanceof Error) {
                setError(error.message);
            } else {
                setError("An unexpected error occurred");
            }
        } finally {
            setLoading(false);
        }
    };

    const availableServices =
        formData.role !== "user" ? servicesByRole[formData.role] || [] : [];

    return (
        <div
            className="flex bg-cover bg-center flex-col md:flex-row py-2"
            style={{ backgroundImage: `url(${bg.src})` }}
        >
            <div className="flex-1 flex items-center justify-center p-8 bg-black bg-opacity-60">
                <div className="text-white text-center md:text-start">
                    <h1 className="text-4xl mb-4 font-bold leading-tight text-cyan">
                        Find Your Dream Property
                    </h1>
                    <p className="text-lg mb-8">
                        Join us and explore a wide range of properties to buy,
                        rent, or invest in. Sign up now to discover exclusive
                        deals and opportunities!
                    </p>
                </div>
            </div>
            <div className="flex-1 flex items-center justify-center md:p-8 p-0 bg-black bg-opacity-60">
                <div className="bg-white md:p-8 p-3 rounded-lg shadow-xl w-full max-w-md">
                    <h2 className="text-3xl font-bold mb-6 text-center">
                        Create Your Account
                    </h2>

                    {error && (
                        <div className="text-red-500 text-sm mb-4">{error}</div>
                    )}

                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div>
                            <Label htmlFor="name">Name</Label>
                            <Input
                                id="name"
                                name="name"
                                type="text"
                                placeholder="Enter your name"
                                value={formData.name}
                                onChange={handleChange}
                                required
                            />
                        </div>
                        <div>
                            <Label htmlFor="email">Email</Label>
                            <Input
                                id="email"
                                name="email"
                                type="email"
                                placeholder="Enter your email"
                                value={formData.email}
                                onChange={handleChange}
                                required
                            />
                        </div>
                        <div>
                            <Label htmlFor="password">Password</Label>
                            <Input
                                id="password"
                                name="password"
                                type="password"
                                placeholder="Create a password"
                                value={formData.password}
                                onChange={handleChange}
                                required
                            />
                        </div>
                        <div>
                            <Label htmlFor="phone">Phone Number</Label>
                            <Input
                                id="phone"
                                name="phone"
                                type="text"
                                placeholder="Enter Your Phone Number"
                                value={formData.phone}
                                onChange={handleChange}
                                required
                            />
                        </div>
                        <div>
                            <Label htmlFor="role">Role</Label>
                            <Select
                                value={formData.role}
                                onValueChange={(value) =>
                                    setFormData({ ...formData, role: value })
                                }
                                required
                            >
                                <SelectTrigger className="w-full">
                                    <SelectValue placeholder="Select a role" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="builder">Builder</SelectItem>
                                    <SelectItem value="agent">Agent</SelectItem>
                                    <SelectItem value="owner">Owner</SelectItem>
                                    <SelectItem value="service_provider">
                                        Service Provider
                                    </SelectItem>
                                    <SelectItem value="user">User</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        {availableServices.length > 0 && (
                            <div>
                                <Label>Add Service</Label>
                                <div className="space-y-4">
                                    <div>
                                        <Label>Service Name</Label>
                                        <Select
                                            value={newService.name}
                                            onValueChange={(value) =>
                                                setNewService({
                                                    ...newService,
                                                    name: value,
                                                })
                                            }
                                        >
                                            <SelectTrigger className="w-full">
                                                <SelectValue placeholder="Select a service" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                {availableServices.map((service) => (
                                                    <SelectItem
                                                        key={service}
                                                        value={service}
                                                    >
                                                        {service}
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div>
                                        <Label>Service Description</Label>
                                        <Textarea
                                            name="description"
                                            value={newService.description}
                                            onChange={handleNewServiceChange}
                                            placeholder="Enter service description"
                                        />
                                    </div>
                                    <div>
                                        <Label>Category</Label>
                                        <Input
                                            name="category"
                                            value={newService.category}
                                            onChange={handleNewServiceChange}
                                            placeholder="Enter service category"
                                        />
                                    </div>
                                    <Button
                                        type="button"
                                        className="mt-4 bg-cyan"
                                        onClick={addService}
                                    >
                                        Add Service
                                    </Button>
                                </div>
                            </div>
                        )}
                        <div>
                            <Label htmlFor="image">Profile Image</Label>
                            <Input
                                id="image"
                                name="image"
                                type="file"
                                accept="image/*"
                                onChange={handleImageChange}
                            />
                        </div>
                        <Button
                            type="submit"
                            className="w-full bg-cyan"
                            disabled={loading}
                        >
                            {loading ? "Registering..." : "Register"}
                        </Button>
                    </form>
                    <p className="mt-4 text-center text-sm text-gray-500">
                        Already have an account?
                        <Link href="/auth/signin" className="ml-1 text-blue-500">
                            Log In
                        </Link>
                    </p>
                </div>
            </div>
        </div>
    );
};

export default RegisterForm;
