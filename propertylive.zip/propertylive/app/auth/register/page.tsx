// app/auth/register/page.tsx
import React from "react";
import RegisterForm from "./RegisterForm";
import { redirect } from "next/navigation";
import { getServerSession } from "next-auth/next";

import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
} from "@/components/ui/card";

export default async function RegisterPage() {
    const session = await getServerSession();

    if (session) {
        redirect("/profile");
    }

    return <RegisterForm />;
}
