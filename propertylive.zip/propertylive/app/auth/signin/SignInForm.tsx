'use client';

import React, { useState, FormEvent } from 'react';
import { signIn, SignInResponse } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import bg from "@/public/bg-pic1.svg"; // Same background as Register page
import Link from "next/link";


interface FormData {
  email: string;
  password: string;
}

const SignInForm: React.FC = () => {
  const [formData, setFormData] = useState<FormData>({
    email: '',
    password: '',
  });
  const [error, setError] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const router = useRouter();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
        const result = await signIn('credentials', {
            ...formData,
            redirect: false,
        });

        if (result?.error) {
            setError('Invalid email or password');
        } else {
            // Fetch user session to get the role
            const session = await fetch('/api/auth/session').then((res) => res.json());

            if (session.user.role === 'ADMIN') {
                router.push('/admin/dashboard'); // Redirect admins to dashboard
            } else {
                router.push('/'); // Redirect regular users
            }
        }
    } catch (error) {
        setError('An unexpected error occurred');
    } finally {
        setLoading(false);
    }
};

  return (
    <div
      className="flex h-screen bg-cover bg-center md:flex-row flex-col w-full"
      style={{ backgroundImage: `url(${bg.src})` }}
    >
      {/* Left Section: Heading and Description */}
      <div className="flex-1 flex items-center justify-center bg-black bg-opacity-60">
        <div className="text-white">
          <h1 className="text-4xl font-bold leading-tight text-cyan text-center md:text-start">
            Welcome Back
          </h1>
          <p className="text-lg text-center md:text-start">
            Sign in to explore the best property deals, tailored just for you.
          </p>
        </div>
      </div>

      {/* Right Section: Login Form */}
      <div className="flex-1 flex items-center justify-center  bg-black bg-opacity-60">
        <div className="bg-white md:p-8 p-4 rounded-lg shadow-xl w-full max-w-md">
          <h2 className="text-3xl font-bold mb-6 text-center">Sign In</h2>

          {error && (
            <div className="text-red-500 text-sm mb-4">{error}</div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder="Enter your email"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                name="password"
                type="password"
                placeholder="Enter your password"
                value={formData.password}
                onChange={handleChange}
                required
              />
            </div>
            <Button
              type="submit"
              className="w-full bg-cyan"
              disabled={loading}
            >
              {loading ? 'Signing in...' : 'Sign In'}
            </Button>
          </form>

          <p className="mt-4 text-center text-sm text-gray-500">
            Don't have an account?
            <Link href='/auth/register' className='ml-1 text-blue-500'>
              Register Now
              </Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default SignInForm;
