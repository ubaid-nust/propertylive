// app/auth/signin/page.tsx
import React from 'react';
import SignInForm from './SignInForm';
import { redirect } from 'next/navigation';
import { getServerSession } from "next-auth/next";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default async function SignInPage() {
  const session = await getServerSession();

  if (session) {
    redirect('/profile');
  }

  return (
          <SignInForm />
  );
}
