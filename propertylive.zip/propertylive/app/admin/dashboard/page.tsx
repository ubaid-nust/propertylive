"use client";

import React, { useEffect, useState } from "react";

interface Service {
    id: string;
    name: string;
    status: string;
    provider: {
        name: string;
        email: string;
        role: string;
    };
}

export default function AdminDashboard() {
    const [services, setServices] = useState<Service[]>([]);

    // Fetch pending services
    useEffect(() => {
        const fetchServices = async () => {
            const response = await fetch("/api/admin/services/pending");
            if (response.ok) {
                const data = await response.json();
                setServices(data);
            }
        };

        fetchServices();
    }, []);

    const handleApprove = async (id: string) => {
        await fetch(`/api/admin/services/${id}/approve`, {
            method: "PUT",
        });
        setServices((prev) => prev.filter((service) => service.id !== id));
    };

    const handleReject = async (id: string) => {
        await fetch(`/api/admin/services/${id}/reject`, {
            method: "DELETE",
        });
        setServices((prev) => prev.filter((service) => service.id !== id));
    };

    return (
        <div className="p-6">
            <h1 className="text-3xl font-bold mb-6">Admin Dashboard</h1>
            {services.length === 0 ? (
                <p>No pending services.</p>
            ) : (
                <ul className="space-y-4">
                    {services.map((service) => (
                        <li
                            key={service.id}
                            className="p-4 border rounded-lg shadow-sm"
                        >
                            <h2 className="text-xl font-bold">{service.name}</h2>
                            <p>Provider: {service.provider.name}</p>
                            <p>Email: {service.provider.email}</p>
                            <p>Role: {service.provider.role}</p>
                            <div className="mt-4 space-x-4">
                                <button
                                    className="bg-green-500 text-white px-4 py-2 rounded-lg"
                                    onClick={() => handleApprove(service.id)}
                                >
                                    Approve
                                </button>
                                <button
                                    className="bg-red-500 text-white px-4 py-2 rounded-lg"
                                    onClick={() => handleReject(service.id)}
                                >
                                    Reject
                                </button>
                            </div>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
}
