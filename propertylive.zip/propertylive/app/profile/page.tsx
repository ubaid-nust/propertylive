// app/profile/page.tsx
import { getServerSession } from "next-auth/next";
import { redirect } from 'next/navigation';
import prisma from '@/lib/prisma';
import ProfileForm from './ProfileForm';
import UserDashboard from "./userDashboard";
import { UserRole } from '@prisma/client';

export interface UserProfile {
  id: string;
  name: string | null;
  email: string | null;
  image: string | null;
  role: UserRole;
  createdAt: Date;
}

async function getUserProfile(email: string): Promise<UserProfile | null> {
  const user = await prisma.user.findUnique({
    where: { email },
    select: {
      id: true,
      name: true,
      email: true,
      image: true,
      role: true,
      createdAt: true,
    },
  });
  return user;
}

export default async function ProfilePage() {
  const session = await getServerSession();

  if (!session || !session.user?.email) {
    redirect('/auth/signin');
  }

  const user = await getUserProfile(session.user.email);

  if (!user) {
    redirect('/auth/signin');
  }

  return <UserDashboard user={user}/>;
}

  // return (
  //   <div className="container mx-auto px-4 py-12">
  //     <h1 className="text-3xl font-extrabold text-gray-800 mb-6 text-center">Your Profile</h1>

  //     <div className="bg-white shadow-lg rounded-lg p-8 mb-8 max-w-2xl mx-auto">
  //       <form className="space-y-6">
  //         {/* Name Input */}
  //         <div>
  //           <label className="block text-gray-700 font-semibold mb-2">Name</label>
  //           <input
  //             type="text"
  //             value={user.name || 'Not set'}
  //             disabled
  //             className="w-full px-4 py-2 border rounded-md bg-gray-100 text-gray-700 shadow-sm focus:outline-none"
  //           />
  //         </div>

  //         {/* Email Input */}
  //         <div>
  //           <label className="block text-gray-700 font-semibold mb-2">Email</label>
  //           <input
  //             type="email"
  //             value={user.email || 'Not set'}
  //             disabled
  //             className="w-full px-4 py-2 border rounded-md bg-gray-100 text-gray-700 shadow-sm focus:outline-none"
  //           />
  //         </div>

  //         {/* Role Input */}
  //         <div>
  //           <label className="block text-gray-700 font-semibold mb-2">Role</label>
  //           <input
  //             type="text"
  //             value={user.role || 'Not set'}
  //             disabled
  //             className="w-full px-4 py-2 border rounded-md bg-gray-100 text-gray-700 shadow-sm focus:outline-none"
  //           />
  //         </div>

  //         {/* Member Since Input */}
  //         <div>
  //           <label className="block text-gray-700 font-semibold mb-2">Member Since</label>
  //           <input
  //             type="text"
  //             value={new Date(user.createdAt).toLocaleDateString()}
  //             disabled
  //             className="w-full px-4 py-2 border rounded-md bg-gray-100 text-gray-700 shadow-sm focus:outline-none"
  //           />
  //         </div>
  //       </form>

  //       {/* Optionally add the ProfileForm for editing */}
  //       <ProfileForm user={user} />
  //     </div>
  //   </div>
  // );
// }