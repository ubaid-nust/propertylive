"use client";

import React from "react";
import { Button } from "@/components/ui/button";
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
} from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Home, Heart, Search, Bell, Settings, LogOut } from "lucide-react";
import { useSession, signOut } from "next-auth/react";
import Link from "next/link";
import { UserProfile } from "./page";

interface UserDashboardProps {
    user: UserProfile;
}

export default function UserDashboard({ user }: UserDashboardProps) {
    const [activeTab, setActiveTab] = React.useState("overview");

    return (
        <div className="container mx-auto p-4 mt-7">
            <div className="flex flex-col md:flex-row gap-6">
                {/* Sidebar */}
                <aside className="w-full md:w-64 space-y-4">
                    <Card>
                        <CardContent className="p-4 flex flex-col items-center">
                            <Avatar className="w-24 h-24">
                            <AvatarImage
                                    src={
                                        user.image
                                            ? `${user.image}`
                                            : "/placeholder.svg?height=96&width=96"
                                    }
                                    alt={user.name || "User"}
                                />
                                <AvatarFallback>
                                    {user.name
                                        ? user.name
                                              .substring(0, 2)
                                              .toUpperCase()
                                        : "U"}
                                </AvatarFallback>
                            </Avatar>
                            <h2 className="mt-4 text-xl font-bold">
                                {user.name}
                            </h2>
                            <p className="text-sm text-gray-500">
                                {user.email}
                            </p>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="p-4">
                            <nav className="space-y-2">
                                <Button
                                    variant="ghost"
                                    className="w-full justify-start"
                                    onClick={() => setActiveTab("overview")}
                                >
                                    <Home className="mr-2 h-4 w-4" />
                                    Overview
                                </Button>
                                <Button
                                    variant="ghost"
                                    className="w-full justify-start"
                                    onClick={() => setActiveTab("listings")}
                                >
                                    <Search className="mr-2 h-4 w-4" />
                                    My Listings
                                </Button>
                                <Button
                                    variant="ghost"
                                    className="w-full justify-start"
                                    onClick={() => setActiveTab("saved")}
                                >
                                    <Heart className="mr-2 h-4 w-4" />
                                    Saved Properties
                                </Button>
                                <Button
                                    variant="ghost"
                                    className="w-full justify-start"
                                    onClick={() =>
                                        setActiveTab("notifications")
                                    }
                                >
                                    <Bell className="mr-2 h-4 w-4" />
                                    Notifications
                                </Button>
                                <Button
                                    variant="ghost"
                                    className="w-full justify-start"
                                    onClick={() => setActiveTab("settings")}
                                >
                                    <Settings className="mr-2 h-4 w-4" />
                                    Account Settings
                                </Button>
                                <Button
                                    variant="ghost"
                                    className="w-full justify-start text-red-500"
                                    onClick={() => signOut()}
                                >
                                    <LogOut className="mr-2 h-4 w-4" />
                                    Logout
                                </Button>
                            </nav>
                        </CardContent>
                    </Card>
                </aside>

                {/* Main Content */}
                <main className="flex-1">
                    <Tabs value={activeTab} onValueChange={setActiveTab}>
                        <TabsList className="grid w-full grid-cols-5">
                            <TabsTrigger value="overview">Overview</TabsTrigger>
                            <TabsTrigger value="listings">
                                My Listings
                            </TabsTrigger>
                            <TabsTrigger value="saved">Saved</TabsTrigger>
                            <TabsTrigger value="notifications">
                                Notifications
                            </TabsTrigger>
                            <TabsTrigger value="settings">Settings</TabsTrigger>
                        </TabsList>
                        <TabsContent value="overview">
                            <Card>
                                <CardHeader>
                                    <CardTitle>Dashboard Overview</CardTitle>
                                    <CardDescription>
                                        Welcome back, {user.name}! Here's a
                                        summary of your real estate activity.
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                                        <Card>
                                            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                                <CardTitle className="text-sm font-medium">
                                                    Active Listings
                                                </CardTitle>
                                                <Home className="h-4 w-4 text-muted-foreground" />
                                            </CardHeader>
                                            <CardContent>
                                                <div className="text-2xl font-bold">
                                                    5
                                                </div>
                                            </CardContent>
                                        </Card>
                                        <Card>
                                            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                                <CardTitle className="text-sm font-medium">
                                                    Saved Properties
                                                </CardTitle>
                                                <Heart className="h-4 w-4 text-muted-foreground" />
                                            </CardHeader>
                                            <CardContent>
                                                <div className="text-2xl font-bold">
                                                    12
                                                </div>
                                            </CardContent>
                                        </Card>
                                        <Card>
                                            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                                <CardTitle className="text-sm font-medium">
                                                    Property Views
                                                </CardTitle>
                                                <Search className="h-4 w-4 text-muted-foreground" />
                                            </CardHeader>
                                            <CardContent>
                                                <div className="text-2xl font-bold">
                                                    1,234
                                                </div>
                                            </CardContent>
                                        </Card>
                                        <Card>
                                            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                                <CardTitle className="text-sm font-medium">
                                                    New Messages
                                                </CardTitle>
                                                <Bell className="h-4 w-4 text-muted-foreground" />
                                            </CardHeader>
                                            <CardContent>
                                                <div className="text-2xl font-bold">
                                                    3
                                                </div>
                                            </CardContent>
                                        </Card>
                                    </div>
                                </CardContent>
                            </Card>
                        </TabsContent>
                        <TabsContent value="listings">
                            <Card>
                                <CardHeader>
                                    <CardTitle>My Listings</CardTitle>
                                    <CardDescription>
                                        Manage your property listings here.
                                    </CardDescription>
                                    <Button className="mx-3">
                                        <Link href="/dashboard/properties">
                                            View My Listings
                                        </Link>
                                    </Button>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-4">
                                        {[1, 2, 3, 4, 5].map((listing) => (
                                            <Card key={listing}>
                                                <CardContent className="flex items-center p-4">
                                                    <div className="h-16 w-16 rounded-md bg-gray-200 mr-4"></div>
                                                    <div>
                                                        <h3 className="font-semibold">
                                                            Property Listing{" "}
                                                            {listing}
                                                        </h3>
                                                        <p className="text-sm text-gray-500">
                                                            123 Main St,
                                                            Anytown, USA
                                                        </p>
                                                    </div>
                                                    <Button className="ml-auto">
                                                        Edit
                                                    </Button>
                                                </CardContent>
                                            </Card>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>
                        </TabsContent>
                        <TabsContent value="saved">
                            <Card>
                                <CardHeader>
                                    <CardTitle>Saved Properties</CardTitle>
                                    <CardDescription>
                                        View and manage your saved properties.
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-4">
                                        {[1, 2, 3].map((property) => (
                                            <Card key={property}>
                                                <CardContent className="flex items-center p-4">
                                                    <div className="h-16 w-16 rounded-md bg-gray-200 mr-4"></div>
                                                    <div>
                                                        <h3 className="font-semibold">
                                                            Saved Property{" "}
                                                            {property}
                                                        </h3>
                                                        <p className="text-sm text-gray-500">
                                                            456 Elm St,
                                                            Somewhere, USA
                                                        </p>
                                                    </div>
                                                    <Button
                                                        variant="outline"
                                                        className="ml-auto"
                                                    >
                                                        View
                                                    </Button>
                                                </CardContent>
                                            </Card>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>
                        </TabsContent>
                        <TabsContent value="notifications">
                            <Card>
                                <CardHeader>
                                    <CardTitle>Notifications</CardTitle>
                                    <CardDescription>
                                        Stay updated with your account activity.
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-4">
                                        {[1, 2, 3].map((notification) => (
                                            <Card key={notification}>
                                                <CardContent className="flex items-center p-4">
                                                    <Bell className="h-6 w-6 mr-4 text-blue-500" />
                                                    <div>
                                                        <h3 className="font-semibold">
                                                            New Message
                                                        </h3>
                                                        <p className="text-sm text-gray-500">
                                                            You have a new
                                                            message regarding
                                                            Property Listing{" "}
                                                            {notification}
                                                        </p>
                                                    </div>
                                                </CardContent>
                                            </Card>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>
                        </TabsContent>
                        <TabsContent value="settings">
                            <Card>
                                <CardHeader>
                                    <CardTitle>Account Settings</CardTitle>
                                    <CardDescription>
                                        Manage your account preferences and
                                        information.
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <form className="space-y-4">
                                        <div className="grid gap-2">
                                            <Label htmlFor="name">Name</Label>
                                            <Input
                                                id="name"
                                                defaultValue={user.name || ""}
                                            />
                                        </div>
                                        <div className="grid gap-2">
                                            <Label htmlFor="email">Email</Label>
                                            <Input
                                                id="email"
                                                defaultValue={user.email || ""}
                                            />
                                        </div>
                                        <div className="grid gap-2">
                                            <Label htmlFor="role">Role</Label>
                                            <Input
                                                id="role"
                                                value={user.role}
                                                disabled
                                            />
                                        </div>
                                        <div className="grid gap-2">
                                            <Label htmlFor="createdAt">
                                                Member Since
                                            </Label>
                                            <Input
                                                id="createdAt"
                                                value={user.createdAt.toLocaleDateString()}
                                                disabled
                                            />
                                        </div>
                                        <Button>Save Changes</Button>
                                    </form>
                                </CardContent>
                            </Card>
                        </TabsContent>
                    </Tabs>
                </main>
            </div>
        </div>
    );
}
