import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Footer } from "@/components/Footer";
import Navbar from "@/components/Header"; // Ensure Navbar is imported correctly
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import SessionProvider from "./SessionProvider";
import { Session } from "next-auth";

const inter = Inter({ subsets: ["latin"] });

export const metadata = {
    title: "Property Live - Welcome",
    description: "Property Live.",
};

export default async function RootLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    const session: Session | null = await getServerSession(authOptions);

    return (
        <html lang="en">
            <body className={inter.className}>
                <SessionProvider session={session}>
                    <Navbar />
                    <main className="md:pt-20">{children}</main>
                </SessionProvider>
                <Footer />
            </body>
        </html>
    );
}
