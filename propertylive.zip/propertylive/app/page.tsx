// app/page.tsx
import React from 'react';
import Header from '@/components/Header';
import { Hero } from '@/components/home/Hero';
import PropertySearch from '@/components/PropertySearch';
import { QuickLinks } from '@/components/QuickLinks';
import { FeaturedProperties } from '@/components/FeaturedProperties';
import PropertyListing from '@/components/PropertyListing';
import { Footer } from '@/components/Footer';

export default function HomePage() {
  
  return (
    <div className="min-h-screen bg-black">
      <main>
        <Hero />
        <PropertySearch />
        <QuickLinks />
        <FeaturedProperties />
        <PropertyListing />
      </main>
    </div>
  );
}