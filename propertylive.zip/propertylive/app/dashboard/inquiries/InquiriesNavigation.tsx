// app/dashboard/inquiries/InquiriesNavigation.tsx
'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

export default function InquiriesNavigation() {
  const pathname = usePathname();

  return (
    <nav className="flex space-x-4 mb-4">
      <Link 
        href="/dashboard/inquiries/sent" 
        className={`px-3 py-2 rounded-md ${
          pathname === '/dashboard/inquiries/sent' 
            ? 'bg-blue-500 text-white' 
            : 'bg-gray-200 text-gray-700'
        }`}
      >
        Sent Inquiries
      </Link>
      <Link 
        href="/dashboard/inquiries/received" 
        className={`px-3 py-2 rounded-md ${
          pathname === '/dashboard/inquiries/received' 
            ? 'bg-blue-500 text-white' 
            : 'bg-gray-200 text-gray-700'
        }`}
      >
        Received Inquiries
      </Link>
    </nav>
  );
}