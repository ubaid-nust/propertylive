// app/dashboard/inquiries/layout.tsx
import InquiriesNavigation from './InquiriesNavigation';

export default function InquiriesLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Inquiries Dashboard</h1>
      <InquiriesNavigation />
      {children}
    </div>
  );
}