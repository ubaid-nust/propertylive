// app/dashboard/inquiries/received/page.tsx
import { getServerSession } from 'next-auth/next';
import prisma from '@/lib/prisma';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import InquiriesPagination from '../InquiriesPagination';

async function getReceivedInquiries(userId: string, page: number = 1, limit: number = 10) {
  const skip = (page - 1) * limit;
  const inquiries = await prisma.inquiry.findMany({
    where: { property: { userId } },
    include: { property: true },
    orderBy: { createdAt: 'desc' },
    skip,
    take: limit,
  });
  const total = await prisma.inquiry.count({ where: { property: { userId } } });

  return {
    inquiries,
    total,
    totalPages: Math.ceil(total / limit),
  };
}

export default async function ReceivedInquiriesPage({ 
  searchParams 
}: { 
  searchParams: { page?: string } 
}) {
  const session = await getServerSession();
  if (!session || !session.user) {
    return <div>Please log in to view received inquiries.</div>;
  }

  const page = searchParams.page ? parseInt(searchParams.page) : 1;
  const { inquiries, total, totalPages } = await getReceivedInquiries(session.user.id, page);

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-4">Received Inquiries</h1>
      {inquiries.length === 0 ? (
        <p>You haven't received any inquiries yet.</p>
      ) : (
        <>
          {inquiries.map((inquiry) => (
            <Card key={inquiry.id} className="mb-4">
              <CardHeader>
                <CardTitle>{inquiry.property.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p><strong>From:</strong> {inquiry.name} ({inquiry.email})</p>
                <p><strong>Received on:</strong> {inquiry.createdAt.toLocaleDateString()}</p>
                <p><strong>Message:</strong> {inquiry.message}</p>
                <Button asChild className="mt-2">
                  <Link href={`/dashboard/properties/${inquiry.property.id}`}>
                    View Property
                  </Link>
                </Button>
              </CardContent>
            </Card>
          ))}
          <InquiriesPagination currentPage={page} totalPages={totalPages} />
        </>
      )}
    </div>
  );
}