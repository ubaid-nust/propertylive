export default function Inquiries({ params }: { params: { id: string } }) {
  return (
    <div>
    </div>
  );
}