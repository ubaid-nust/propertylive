// app/dashboard/inquiries/InquiriesPagination.tsx
'use client';

import Link from 'next/link';
import { usePathname, useSearchParams } from 'next/navigation';

interface InquiriesPaginationProps {
  currentPage: number;
  totalPages: number;
}

export default function InquiriesPagination({ currentPage, totalPages }: InquiriesPaginationProps) {
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const createPageURL = (pageNumber: number | string) => {
    const params = new URLSearchParams(searchParams);
    params.set('page', pageNumber.toString());
    return `${pathname}?${params.toString()}`;
  };

  return (
    <div className="flex justify-center space-x-2 mt-4">
      {currentPage > 1 && (
        <Link href={createPageURL(currentPage - 1)} className="px-3 py-2 bg-gray-200 rounded-md">
          Previous
        </Link>
      )}
      {currentPage < totalPages && (
        <Link href={createPageURL(currentPage + 1)} className="px-3 py-2 bg-gray-200 rounded-md">
          Next
        </Link>
      )}
    </div>
  );
}