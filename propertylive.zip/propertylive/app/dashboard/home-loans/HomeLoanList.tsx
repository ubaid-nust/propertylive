// app/home-loans/HomeLoanList.tsx
import Link from 'next/link';
import { getServerSession } from 'next-auth/next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"
import prisma from '@/lib/prisma';

async function getHomeLoans(userId: string, page = 1) {
  const pageSize = 10;
  const skip = (page - 1) * pageSize;

  const homeLoans = await prisma.homeLoan.findMany({
    where: { userId },
    skip,
    take: pageSize,
    orderBy: { createdAt: 'desc' },
  });

  const totalLoans = await prisma.homeLoan.count({ where: { userId } });

  return {
    homeLoans,
    totalPages: Math.ceil(totalLoans / pageSize),
  };
}

export default async function HomeLoanList({ page = '1' }: { page?: string }) {
  const session = await getServerSession();
  if (!session || !session.user) {
    return <div>Please log in to view your home loans.</div>;
  }

  const pageNumber = parseInt(page);
  const { homeLoans, totalPages } = await getHomeLoans(session.user.id, pageNumber);

  return (
    <div>
      {homeLoans.map((loan) => (
        <Card key={loan.id} className="mb-4">
          <CardHeader>
            <CardTitle>Loan Amount: ${loan.amount.toLocaleString()}</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Interest Rate: {loan.interestRate}%</p>
            <p>Term: {loan.term} months</p>
            <p>Status: {loan.status}</p>
            <div className="mt-4">
              <Button asChild variant="outline">
                <Link href={`/dashboard/home-loans/${loan.id}`}>View Details</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
      <Pagination>
        <PaginationContent>
          <PaginationItem>
            <PaginationPrevious 
              href={pageNumber > 1 ? `/home-loans?page=${pageNumber - 1}` : '#'} 
              aria-disabled={pageNumber <= 1}
            />
          </PaginationItem>
          {[...Array(totalPages)].map((_, index) => (
            <PaginationItem key={index}>
              <PaginationLink 
                href={`/home-loans?page=${index + 1}`}
                isActive={pageNumber === index + 1}
              >
                {index + 1}
              </PaginationLink>
            </PaginationItem>
          ))}
          <PaginationItem>
            <PaginationNext 
              href={pageNumber < totalPages ? `/home-loans?page=${pageNumber + 1}` : '#'}
              aria-disabled={pageNumber >= totalPages}
            />
          </PaginationItem>
        </PaginationContent>
      </Pagination>
    </div>
  );
}