// app/home-loans/page.tsx
import { Suspense } from 'react';
import Link from 'next/link';
import HomeLoanList from './HomeLoanList';
import { Button } from '@/components/ui/button';

export default async function HomeLoansPage({
  searchParams
}: {
  searchParams: { page?: string }
}) {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Your Home Loans</h1>
        <Button asChild>
          <Link href="home-loans/apply">Apply for a Home Loan</Link>
        </Button>
      </div>
      <Suspense fallback={<div>Loading home loans...</div>}>
        <HomeLoanList page={searchParams.page} />
      </Suspense>
    </div>
  );
}