// app/home-loans/apply/page.tsx
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/components/ui/use-toast";

const homeLoanSchema = z.object({
  amount: z.number().positive('Amount must be positive'),
  interestRate: z.number().positive('Interest rate must be positive').max(100, 'Interest rate cannot exceed 100%'),
  term: z.number().int().positive('Term must be a positive integer'),
});

type HomeLoanFormData = z.infer<typeof homeLoanSchema>;

export default function HomeLoanApplicationPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<HomeLoanFormData>({
    resolver: zodResolver(homeLoanSchema),
    defaultValues: {
      amount: 0,
      interestRate: 0,
      term: 0,
    },
  });

  const onSubmit = async (data: HomeLoanFormData) => {
    setIsSubmitting(true);
    try {
      const response = await fetch('/api/home-loans', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to submit loan application');
      }

      toast({
        title: "Success",
        description: "Your loan application has been submitted successfully",
      });

      router.push('/dashboard/home-loans');
    } catch (error) {
      console.error('Error submitting loan application:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to submit loan application. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };


  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Apply for a Home Loan</h1>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <FormField
            control={form.control}
            name="amount"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Loan Amount ($)</FormLabel>
                <FormControl>
                  <Input type="number" {...field} onChange={(e) => field.onChange(parseFloat(e.target.value))} />
                </FormControl>
                <FormDescription>Enter the amount you wish to borrow</FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="interestRate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Interest Rate (%)</FormLabel>
                <FormControl>
                  <Input type="number" step="0.01" {...field} onChange={(e) => field.onChange(parseFloat(e.target.value))} />
                </FormControl>
                <FormDescription>Enter the annual interest rate</FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="term"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Loan Term (months)</FormLabel>
                <FormControl>
                  <Input type="number" {...field} onChange={(e) => field.onChange(parseInt(e.target.value))} />
                </FormControl>
                <FormDescription>Enter the loan term in months</FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? 'Submitting...' : 'Apply for Loan'}
          </Button>
        </form>
      </Form>
    </div>
  );
}