// app/home-loans/[id]/page.tsx
import { notFound } from 'next/navigation';
import { getServerSession } from 'next-auth/next';
import prisma from '@/lib/prisma';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';

async function getHomeLoan(id: string, userEmail: string) {
  // First, find the user by email
  const user = await prisma.user.findUnique({
    where: { email: userEmail },
  });

  if (!user) {
    return null;
  }

  // Then, find the loan using the user's ID
  const loan = await prisma.homeLoan.findFirst({
    where: { 
      id,
      userId: user.id
    },
  });

  if (!loan) {
    return null;
  }

  // Return both loan and user data
  return { loan, user };
}

export default async function HomeLoanDetailPage({ params }: { params: { id: string } }) {
  const session = await getServerSession();
  if (!session || !session.user || !session.user.email) {
    return <div>Please log in to view this page.</div>;
  }

  const result = await getHomeLoan(params.id, session.user.email);

  if (!result) {
    notFound();
  }

  const { loan, user } = result;

  return (
    <div className="container mx-auto px-4 py-8">
      <Card>
        <CardHeader>
          <CardTitle>Home Loan Details</CardTitle>
        </CardHeader>
        <CardContent>
          <p><strong>Amount:</strong> ${loan.amount.toLocaleString()}</p>
          <p><strong>Interest Rate:</strong> {loan.interestRate}%</p>
          <p><strong>Term:</strong> {loan.term} months</p>
          <p><strong>Status:</strong> {loan.status}</p>
          <p><strong>Applied On:</strong> {loan.createdAt.toLocaleDateString()}</p>
          <p><strong>Last Updated:</strong> {loan.updatedAt.toLocaleDateString()}</p>
          <p><strong>Applicant:</strong> {user.name || user.email}</p>
          <div className="mt-4">
            <Button asChild>
              <Link href={`/home-loans/${loan.id}/edit`}>Edit Loan</Link>
            </Button>
            <Button variant="destructive" className="ml-2">
              Cancel Loan
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}   