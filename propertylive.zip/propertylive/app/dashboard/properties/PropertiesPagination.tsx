// app/dashboard/properties/PropertiesPagination.tsx
'use client';

import Link from 'next/link';
import { usePathname, useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';

interface PropertiesPaginationProps {
  currentPage: number;
  totalPages: number;
}

export default function PropertiesPagination({ currentPage, totalPages }: PropertiesPaginationProps) {
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const createPageURL = (pageNumber: number | string) => {
    const params = new URLSearchParams(searchParams);
    params.set('page', pageNumber.toString());
    return `${pathname}?${params.toString()}`;
  };

  return (
    <div className="flex justify-center space-x-2 mt-4">
      {currentPage > 1 && (
        <Button asChild variant="outline">
          <Link href={createPageURL(currentPage - 1)}>Previous</Link>
        </Button>
      )}
      {currentPage < totalPages && (
        <Button asChild variant="outline">
          <Link href={createPageURL(currentPage + 1)}>Next</Link>
        </Button>
      )}
    </div>
  );
}