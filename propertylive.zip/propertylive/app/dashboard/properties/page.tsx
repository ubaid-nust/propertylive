// app/dashboard/properties/page.tsx
import { getServerSession } from "next-auth/next";
import Link from "next/link";
import prisma from "@/lib/prisma";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import DeletePropertyButton from "./DeletePropertyButton";
import PropertiesPagination from "./PropertiesPagination";

async function getProperties(
    userId: string,
    page: number = 1,
    limit: number = 10
) {
    const skip = (page - 1) * limit;
    const properties = await prisma.property.findMany({
        where: { userId },
        orderBy: { createdAt: "desc" },
        skip,
        take: limit,
    });
    const total = await prisma.property.count({ where: { userId } });

    return {
        properties,
        total,
        totalPages: Math.ceil(total / limit),
    };
}

export default async function PropertiesListPage({
    searchParams,
}: {
    searchParams: { page?: string };
}) {
    const session = await getServerSession();
    if (!session || !session.user) {
        return <div>Please log in to view your properties.</div>;
    }

    const page = searchParams.page ? parseInt(searchParams.page) : 1;
    const { properties, total, totalPages } = await getProperties(
        session.user.id,
        page
    );

    return (
        <div className="container mx-auto px-4 py-8">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold">Your Properties</h1>
                <Button asChild>
                    <Link href="/dashboard/properties/new">
                        Add New Property
                    </Link>
                </Button>
            </div>

            {properties.length === 0 ? (
                <p>You haven't added any properties yet.</p>
            ) : (
                <>
                    {properties.map((property) => (
                        <Card key={property.id} className="mb-4">
                            <CardHeader>
                                <CardTitle>{property.title}</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p>
                                    <strong>Price:</strong> $
                                    {property.price.toLocaleString()}
                                </p>
                                <p>
                                    <strong>Type:</strong> {property.type}
                                </p>
                                <p>
                                    <strong>Status:</strong> {property.status}
                                </p>
                                <div className="mt-4 flex space-x-2">
                                    <Button asChild>
                                        <Link
                                            href={`/dashboard/properties/${property.id}`}
                                        >
                                            View Details
                                        </Link>
                                    </Button>
                                    <Button asChild variant="outline">
                                        <Link
                                            href={`/dashboard/properties/edit/${property.id}`}
                                        >
                                            Edit
                                        </Link>
                                    </Button>
                                    <DeletePropertyButton
                                        propertyId={property.id}
                                    />
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                    <PropertiesPagination
                        currentPage={page}
                        totalPages={totalPages}
                    />
                </>
            )}
        </div>
    );
}
