// app/dashboard/properties/PropertyList.tsx
'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Property, Session } from '@/types';

interface PropertyListProps {
  initialProperties: Property[];
  session: Session | null;
}

export default function PropertyList({ initialProperties, session }: PropertyListProps) {
  const router = useRouter();
  const [properties, setProperties] = useState<Property[]>(initialProperties);

  const handleDelete = async (id: string) => {
    const response = await fetch(`/api/properties/${id}`, { method: 'DELETE' });
    if (response.ok) {
      setProperties(properties.filter(property => property.id !== id));
      router.refresh();
    }
  };

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      {properties.map((property) => (
        <Card key={property.id}>
          <CardHeader>
            <CardTitle>{property.title}</CardTitle>
          </CardHeader>
          <CardContent>
            <p>{property.description}</p>
            <p>Price: ${property.price}</p>
            <p>Type: {property.type}</p>
            <p>Status: {property.status}</p>
            {session && session.user.id === property.userId && (
              <Button onClick={() => handleDelete(property.id)} variant="destructive">
                Delete
              </Button>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}