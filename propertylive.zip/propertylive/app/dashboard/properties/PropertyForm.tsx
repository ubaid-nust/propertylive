import React, { useEffect, useCallback, useState, use } from "react";
import { useForm, SubmitHandler, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { getServerSession } from "next-auth/next";
import houseSale from "@/public/house-sale.webp"
import { useRouter } from 'next/navigation';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
    Form,
    FormControl,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from "@/components/ui/form";
import {
    Home,
    MapPin,
    DollarSign,
    BedDouble,
    Bath,
    Maximize,
    Building,
    X,
    Percent,
    Image as ImageIcon,
    FileText,
} from "lucide-react";
import { PropertyStatus, PostedAs, PropertyCategory, PossessionStatus, FurnishingStatus, Authority, AvailableFrom, AgeofC, AreaUnit, SaleType } from "@prisma/client";
import { useDropzone } from "react-dropzone";
import { redirect } from "next/dist/server/api-utils";
import { useToast } from "@/components/ui/use-toast";
import { useWatch } from "react-hook-form";


const MAX_FILE_SIZE = 5 * 1024 * 1024;
const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"];

const propertySchema = z.object({
    title: z.string().min(1, "Title is required"),
    description: z
        .string()
        .min(10, "Description must be at least 10 characters"),
    price: z.coerce.number().positive("Price must be positive"),
    type: z.string(),
    postedAs: z.nativeEnum(PostedAs).optional(),
    category: z.nativeEnum(PropertyCategory).optional(),
    status: z.nativeEnum(PropertyStatus).optional(),
    bedrooms: z.coerce.number().int().nonnegative().optional(),
    bathrooms: z.coerce.number().int().nonnegative().optional(),
    area: z.coerce.number().positive("Area must be positive").optional(),
    address: z.string().min(1, "Address is required").optional(),
    city: z.string().min(1, "City is required").optional(),
    state: z.string().min(1, "State is required").optional(),
    zipCode: z.string().min(1, "Zip code is required").optional(),
    amenities: z.array(z.string()).optional(),
    images: z.array(z.string()).optional(),
    pricenegotiablen: z.boolean().optional(),
    bookingtoken: z.boolean().optional(),
    possessionStatus: z.nativeEnum(PossessionStatus).optional(),
    furnishingStatus: z.nativeEnum(FurnishingStatus).optional(),
    plotspecialization: z.string().optional(),
    approvalauth: z.nativeEnum(Authority).optional(),
    saleType: z.nativeEnum(SaleType),
    totalFloors: z.coerce.number().int().nonnegative().optional(),
    floorNumber: z.string().optional(),
    availableFrom: z.nativeEnum(AvailableFrom).optional(),
    ageofconstruction: z.nativeEnum(AgeofC).optional(),
    balcony: z.coerce.number().int().nonnegative().optional(),
    widthofroadfacing: z.string().optional(),
    constructiondone: z.boolean().optional(),
    boundrywall: z.boolean().optional(),
    gatedcommunity: z.boolean().optional(),
    nooffloorsallowed: z.coerce.number().int().nonnegative().optional(),
    noofopenside: z.coerce.number().int().nonnegative().optional(),
    plotlenght: z.coerce.number().int().nonnegative().optional(),
    plotwidth: z.coerce.number().int().nonnegative().optional(),
    amountofbooking: z.string().optional(),
    mainroadfacing: z.boolean().optional(),
    cafeteria: z.boolean().optional(),
    cornorshowroom: z.boolean().optional(),
    personalwashroom: z.boolean().optional(),
    carpetarea: z.coerce.number().int().nonnegative().optional(),
    superarea: z.coerce.number().int().nonnegative().optional(),
    areaunit: z.nativeEnum(AreaUnit).optional(),
});

export type PropertyFormData = z.infer<typeof propertySchema>;

interface PropertyFormProps {
    propertyId?: string;
    initialData?: PropertyFormData;
    onSubmit?: (data: PropertyFormData) => void;
    isSubmitting?: boolean;
}

export default function PropertyForm({
    propertyId, // Destructure propertyId
    initialData,
}: PropertyFormProps) {
    const [imageFiles, setImageFiles] = useState<File[]>([]);
    const form = useForm<PropertyFormData>({
        resolver: zodResolver(propertySchema),
        defaultValues: initialData || {
            title: "",
            description: "",
            price: 0,
            type: "",
            category: PropertyCategory.COMMERCIAL,
            status: PropertyStatus.FOR_SALE,
            postedAs: PostedAs.OWNER,
            possessionStatus: PossessionStatus.READY_TO_MOVE,
            furnishingStatus: FurnishingStatus.FURNISHED,
            approvalauth: Authority.COH,
            bedrooms: 0,
            bathrooms: 0,
            area: 0,
            address: "",
            city: "",
            state: "",
            zipCode: "",
            amenities: [],
            images: [],
            pricenegotiablen: false,
            bookingtoken: false,
            plotspecialization: "",
            plotlenght: 0,
            plotwidth: 0,
            gatedcommunity: false,
            totalFloors: 0,
            floorNumber: " ",
            availableFrom: AvailableFrom.IMMEDIATELY,
            ageofconstruction: AgeofC.NEW_CONSTRUCTION,
            balcony: 0,
            constructiondone: false,
            boundrywall: false,
            amountofbooking: "",
            mainroadfacing: false,
            cafeteria: false,
            cornorshowroom: false,
            personalwashroom: false,
            carpetarea: 0,
            superarea: 0,
            areaunit: AreaUnit.SQFT,
            saleType: SaleType.RESALE,

        },
    });
    const router = useRouter();
    const { toast } = useToast();

    const handleImageChange = (files: File[]) => {
        setImageFiles(files);
    };
    const [isSubmitting, setIsSubmitting] = useState(false);
    useEffect(() => {
        if (initialData) {
            Object.entries(initialData).forEach(([key, value]) => {
                form.setValue(key as keyof PropertyFormData, value);
            });
        }
    }, [initialData, form]);

    const amenitiesList = [
        "Waste Disposal",
        "Park",
        "Rainwater Harvesting",
        "Water Storage",
        "Indoor Games Room",
        "Security",
        "Gym",
        "Kids Play Area",
        "Power Backup",
        "Reserved Parking",
        "Swimming Pool",
        "Multi-purpose Courts",
        "Lift",
        "Clubhouse",
    ];
    const commercialPT = [
        "Office Space",
        "Office in IT Park/SEZ",
        "Shop",
        "Showroom",
        "Commercial Land",
        "Warehouse",
        "Industrial Land",
        "Industrial Building",
        "Industrial Shed",
        "Agricultural Land",
    ];
    const residentialPT = [
        "Flat/Apartment",
        "House",
        "Villa",
        "Builder Floor",
        "Plot",
        "Studio Apartment",
        "Penthouse",
        "Farmhouse",
    ];
    const bathroomShow = [
        "Shop",
        "Office in IT Park/SEZ",
        "Office Space",
        "Flat/Apartment",
        "House",
        "Villa",
        "Builder Floor",
        "Studio Apartment",
        "Penthouse",
        "Farmhouse",
    ]
    const roomShow = [
        "Flat/Apartment",
        "House",
        "Villa",
        "Builder Floor",
        "Studio Apartment",
        "Penthouse",
        "Farmhouse",
    ]
    const totalFloorsShow = [
        "Flat/Apartment",
        "House",
        "Villa",
        "Builder Floor",
        "Studio Apartment",
        "Penthouse",
        "Farmhouse",
        "Office Space",
        "Office in IT Park/SEZ",
        "Shop",
        "Showroom",
        "Industrial Building",
        "Industrial Shed",
        "Warehouse",
    ]
   const propsWithPossessionStatusAndFurnishing = [
        "Flat/Apartment",
        "House",
        "Villa",
        "Builder Floor",
        "Studio Apartment",
        "Penthouse",
        "Farmhouse",
        "Office Space",
        "Office in IT Park/SEZ",
        "Shop",
        "Showroom",
        "Warehouse",
        "Industrial Building",
        "Industrial Shed",
    ];
    const balconyShow = [
        "Flat/Apartment",
        "House",
        "Villa",
        "Builder Floor",
        "Studio Apartment",
        "Penthouse",
        "Farmhouse"
    ]

    const onDrop = useCallback(
        (acceptedFiles: File[]) => {
            console.log("Accepted files:", acceptedFiles); // Log accepted files
            setImageFiles((prevFiles) => [...prevFiles, ...acceptedFiles]);
            const fileNames = acceptedFiles.map(file => file.name);
            form.setValue("images", [...(form.getValues("images") || []), ...fileNames]);
        },
        [form]
    );
    const balconyCheck = useWatch({
        control: form.control,
        name: "type",
    });
    const totalFloorsCheck = useWatch({
        control: form.control,
        name: "type",
    });
    const selectedCategory = useWatch({
        control: form.control,
        name: "category",
    });
    const cafeCheck = useWatch({
        control: form.control,
        name: "type",
    });
    const selectedPropertyType = useWatch({
        control: form.control,
        name: "type", // This watches the selected property type
    });
    const availableFromwatch = useWatch({
        control: form.control,
        name: "possessionStatus",
    });
    const plotCheck = useWatch({
        control: form.control,
        name: "type",
    });
    const bathroomCheck = useWatch({
        control: form.control,
        name: "type",
    });
    const bedroomShow = useWatch({
        control: form.control,
        name: "type",
    });
    const onSubmitHandler: SubmitHandler<PropertyFormData> = async (data) => {
        setIsSubmitting(true);
        // Create FormData and append images
        const formData = new FormData();
        formData.append('pricenegotiablen', String(data.pricenegotiablen));
        formData.append('bookingtoken', String(data.bookingtoken));
        formData.append('constructiondone', String(data.constructiondone));
        formData.append('boundrywall', String(data.boundrywall));
        formData.append('gatedcommunity', String(data.gatedcommunity));
        formData.append('mainroadfacing', String(data.mainroadfacing));
        formData.append('cafeteria', String(data.cafeteria));
        formData.append('cornorshowroom', String(data.cornorshowroom));
        formData.append('personalwashroom', String(data.personalwashroom));
        // Append property data to FormData
        Object.entries(data).forEach(([key, value]) => {
            if (typeof value === "string" || typeof value === "number") {
                formData.append(key, String(value)); // Ensure all values are strings
            } else if (Array.isArray(value)) {
                value.forEach((item) => formData.append(key, String(item))); // Append each item
            }
        });

        // Append image files to FormData
        imageFiles.forEach((file) => {
            formData.append("imagesfile", file); // Append actual File objects
        });

        // Properly log the FormData contents
        for (const [key, value] of formData.entries()) {
            console.log(`${key}:`, value);
        }
        console.log("HEREEE")
        console.log("fromDta", formData)
        const apiEndpoint = propertyId
            ? `/api/properties/${propertyId}`
            : '/api/properties';
        const json = JSON.stringify(data);
        try {
            const response = await fetch(apiEndpoint, {
                method: propertyId ? 'PUT' : 'POST', // PUT if updating, POST if creating
                body: propertyId ? json : formData,
            });

            if (!response.ok) {
                throw new Error('Failed to submit property');
            }

            toast({
                title: "Success",
                description: propertyId ? "Property updated successfully" : "Property created successfully",
            });

            router.push('/dashboard/properties');
            router.refresh();
        } catch (error) {
            console.error('Error submitting property:', error);
        } finally {
            setIsSubmitting(false);
        }
    };
    const { getRootProps, getInputProps, isDragActive } = useDropzone({
        onDrop,
        accept: {
            "image/jpeg": [".jpg", ".jpeg"],
            "image/png": [".png"],
            "image/webp": [".webp"],
        },
        maxSize: MAX_FILE_SIZE,
    });

    const removeImage = (index: number) => {
        setImageFiles((prevFiles) => prevFiles.filter((_, i) => i !== index));
        const currentImages = form.getValues("images") || [];
        const newImages = [...currentImages.slice(0, index), ...currentImages.slice(index + 1)];
        form.setValue("images", newImages);
    };


    return (
        <>
            <div className="bg-white p-6 rounded-lg border">
                <div className="max-w-6xl mx-auto">
                    <div className="flex flex-col md:flex-row items-center justify-between">
                        <div className="mb-6 md:mb-0 md:mr-6">
                            <h2 className="text-2xl md:text-3xl font-bold text-gray-800 mb-2">
                                Reach Thousands of Buyers on our Platform
                            </h2>
                            <p className="text-gray-500 mb-4">
                                In a few simple steps!
                            </p>
                            <div className="flex flex-wrap gap-4">
                                <div className="flex items-center">
                                    <div className="bg-green-100 p-2 rounded-full mr-2">
                                        <FileText className="w-5 h-5 text-green-600" />
                                    </div>
                                    <span className="text-sm text-gray-600">
                                        Listings Information
                                    </span>
                                </div>
                                <div className="flex items-center">
                                    <div className="bg-green-100 p-2 rounded-full mr-2">
                                        <DollarSign className="w-5 h-5 text-green-600" />
                                    </div>
                                    <span className="text-sm text-gray-600">
                                        Property Price
                                    </span>
                                </div>
                                <div className="flex items-center">
                                    <div className="bg-green-100 p-2 rounded-full mr-2">
                                        <ImageIcon className="w-5 h-5 text-green-600" />
                                    </div>
                                    <span className="text-sm text-gray-600">
                                        Good Property Images
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div className="relative w-full md:w-1/3">
                            <div className="bg-green-100 rounded-lg p-4">
                                <div className="relative z-10">
                                    <div className="w-20 h-20 bg-white rounded-lg shadow-md mb-2"></div>
                                    <Percent className="absolute top-2 right-2 w-8 h-8 text-green-600" />
                                    <div className="flex items-center justify-between">
                                        <div className="w-12 h-6 bg-green-200 rounded"></div>
                                        <div className="w-8 h-12 bg-green-300 rounded"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="my-14 mx-auto bg-white border rounded-xl overflow-hidden">
                <div className="flex flex-col md:flex-row">
                    <div className="w-full md:w-1/3 bg-gray-100 p-6">
                        <h2 className="text-2xl font-bold mt-6 mb-4">
                            <span className="text-gray-900">List a New </span>
                            <span className="text-cyan-500">Property</span>
                        </h2>
                        <p className="text-gray-600">
                            Fill in the details to list your property. Provide
                            accurate information to attract potential buyers or
                            renters.
                        </p>
                    </div>
                    <div className="w-full md:w-2/3 p-6">
                        <Form {...form}>
                            <form
                                onSubmit={form.handleSubmit(onSubmitHandler)}
                                encType="multipart/form-data"
                                className="space-y-6"
                            >
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <FormField
                                        control={form.control}
                                        name="title"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Title</FormLabel>
                                                <FormControl>
                                                    <div className="relative">
                                                        <Home className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                                                        <Input
                                                            {...field}
                                                            className="pl-10"
                                                            placeholder="Cozy Downtown Apartment"
                                                        />
                                                    </div>
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={form.control}
                                        name="price"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Price</FormLabel>
                                                <FormControl>
                                                    <div className="relative">
                                                        <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                                                        <Input
                                                            {...field}
                                                            type="number"
                                                            className="pl-10"
                                                            placeholder="250000"
                                                            onChange={(e) => field.onChange(e.target.valueAsNumber)}
                                                        />
                                                    </div>
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                </div>
                                <h1>Price Negotiable</h1>
                                <FormField
                                    control={form.control}
                                    name="pricenegotiablen"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormControl>
                                                <div className="flex items-center space-x-2 text-gray-600">
                                                    <input
                                                        id="pricenegotiablen"
                                                        type="checkbox"
                                                        checked={field.value}
                                                        onChange={(e) => field.onChange(e.target.checked)}
                                                        className="form-checkbox"
                                                    />
                                                    {/* Associate label with the checkbox using htmlFor */}
                                                    <FormLabel htmlFor="pricenegotiablen">Price Negotiable</FormLabel>
                                                </div>
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="bookingtoken"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormControl>
                                                <div className="flex items-center space-x-2 text-gray-600">
                                                    <input
                                                        id="bookingtoken"
                                                        type="checkbox"
                                                        checked={field.value}
                                                        onChange={(e) => field.onChange(e.target.checked)}
                                                        className="form-checkbox"
                                                    />
                                                    {/* Associate label with the checkbox using htmlFor */}
                                                    <FormLabel htmlFor="bookingtoken">Booking Token</FormLabel>
                                                </div>
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="description"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Description</FormLabel>
                                            <FormControl>
                                                <Textarea
                                                    {...field}
                                                    rows={3}
                                                    placeholder="Describe your property..."
                                                />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <FormField
                                        control={form.control}
                                        name="category"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Property Category</FormLabel>
                                                <Select
                                                    onValueChange={
                                                        field.onChange
                                                    }
                                                    defaultValue={field.value}
                                                >
                                                    <FormControl>
                                                        <SelectTrigger>
                                                            <SelectValue placeholder="Select Category" />
                                                        </SelectTrigger>
                                                    </FormControl>
                                                    <SelectContent>
                                                        {Object.values(
                                                            PropertyCategory
                                                        ).map((category) => (
                                                            <SelectItem
                                                                key={category}
                                                                value={category}
                                                            >
                                                                {category}
                                                            </SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={form.control}
                                        name="saleType"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Sale Type</FormLabel>
                                                <Select
                                                    onValueChange={
                                                        field.onChange
                                                    }
                                                    defaultValue={field.value}
                                                >
                                                    <FormControl>
                                                        <SelectTrigger>
                                                            <SelectValue placeholder="Select Sale Type" />
                                                        </SelectTrigger>
                                                    </FormControl>
                                                    <SelectContent>
                                                        {Object.values(
                                                            SaleType
                                                        ).map((category) => (
                                                            <SelectItem
                                                                key={category}
                                                                value={category}
                                                            >
                                                                {category}
                                                            </SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />

                                    {selectedCategory === PropertyCategory.COMMERCIAL && (
                                        <FormField
                                            control={form.control}
                                            name="type"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Property Type</FormLabel>
                                                    <Select
                                                        onValueChange={field.onChange}
                                                        defaultValue={field.value}
                                                    >
                                                        <FormControl>
                                                            <SelectTrigger>
                                                                <SelectValue placeholder="Select Property Type" />
                                                            </SelectTrigger>
                                                        </FormControl>
                                                        <SelectContent>
                                                            {commercialPT.map((type) => (
                                                                <SelectItem key={type} value={type}>
                                                                    {type}
                                                                </SelectItem>
                                                            ))}
                                                        </SelectContent>
                                                    </Select>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                    )}

                                    {selectedCategory === PropertyCategory.RESIDENTIAL && (
                                        <FormField
                                            control={form.control}
                                            name="type"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Property Type</FormLabel>
                                                    <Select
                                                        onValueChange={field.onChange}
                                                        defaultValue={field.value}
                                                    >
                                                        <FormControl>
                                                            <SelectTrigger>
                                                                <SelectValue placeholder="Select Property Type" />
                                                            </SelectTrigger>
                                                        </FormControl>
                                                        <SelectContent>
                                                            {residentialPT.map((type) => (
                                                                <SelectItem key={type} value={type}>
                                                                    {type}
                                                                </SelectItem>
                                                            ))}
                                                        </SelectContent>
                                                    </Select>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                    )}
                                    <FormField
                                        control={form.control}
                                        name="postedAs"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Posting As</FormLabel>
                                                <Select
                                                    onValueChange={
                                                        field.onChange

                                                    }
                                                    defaultValue={field.value}
                                                >
                                                    <FormControl>
                                                        <SelectTrigger>
                                                            <SelectValue placeholder="Posting As" />
                                                        </SelectTrigger>
                                                    </FormControl>
                                                    <SelectContent>
                                                        {Object.values(
                                                            PostedAs
                                                        ).map((PostedAs) => (
                                                            <SelectItem
                                                                key={PostedAs}
                                                                value={PostedAs}
                                                            >
                                                                {PostedAs}
                                                            </SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                </div>
                                {propsWithPossessionStatusAndFurnishing.includes(selectedPropertyType) && (
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        {/* Possession Status Field */}
                                        <FormField
                                            control={form.control}
                                            name="possessionStatus"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Possession Status</FormLabel>
                                                    <Select
                                                        onValueChange={field.onChange}
                                                        defaultValue={field.value || PossessionStatus.READY_TO_MOVE}
                                                    >
                                                        <FormControl>
                                                            <SelectTrigger>
                                                                <SelectValue placeholder="Select Possession Status" />
                                                            </SelectTrigger>
                                                        </FormControl>
                                                        <SelectContent>
                                                            {Object.values(PossessionStatus).map((status) => (
                                                                <SelectItem key={status} value={status}>
                                                                    {status}
                                                                </SelectItem>
                                                            ))}
                                                        </SelectContent>
                                                    </Select>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />

                                        {/* Furnishing Status Field */}
                                        <FormField
                                            control={form.control}
                                            name="furnishingStatus"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Furnishing Status</FormLabel>
                                                    <Select
                                                        onValueChange={field.onChange}
                                                        defaultValue={field.value || FurnishingStatus.FURNISHED}
                                                    >
                                                        <FormControl>
                                                            <SelectTrigger>
                                                                <SelectValue placeholder="Select Furnishing Status" />
                                                            </SelectTrigger>
                                                        </FormControl>
                                                        <SelectContent>
                                                            {Object.values(FurnishingStatus).map((furnishing) => (
                                                                <SelectItem key={furnishing} value={furnishing}>
                                                                    {furnishing}
                                                                </SelectItem>
                                                            ))}
                                                        </SelectContent>
                                                    </Select>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />

                                        {availableFromwatch === PossessionStatus.UNDER_CONSTRUCTION ? (
                                            <FormField
                                                control={form.control}
                                                name="availableFrom"
                                                render={({ field }) => (
                                                    <FormItem>
                                                        <FormLabel>Available Within</FormLabel>
                                                        <Select
                                                            onValueChange={field.onChange}
                                                            defaultValue={field.value}
                                                        >
                                                            <FormControl>
                                                                <SelectTrigger>
                                                                    <SelectValue placeholder="Select Availability" />
                                                                </SelectTrigger>
                                                            </FormControl>
                                                            <SelectContent>
                                                                {Object.values(AvailableFrom).map((availableFrom) => (
                                                                    <SelectItem
                                                                        key={availableFrom}
                                                                        value={availableFrom}
                                                                    >
                                                                        {availableFrom}
                                                                    </SelectItem>
                                                                ))}
                                                            </SelectContent>
                                                        </Select>
                                                        <FormMessage />
                                                    </FormItem>
                                                )}
                                            />
                                        ) : availableFromwatch === PossessionStatus.READY_TO_MOVE ? (
                                            <FormField
                                                control={form.control}
                                                name="ageofconstruction"
                                                render={({ field }) => (
                                                    <FormItem>
                                                        <FormLabel>Age Of Construction</FormLabel>
                                                        <Select
                                                            onValueChange={field.onChange}
                                                            defaultValue={field.value}
                                                        >
                                                            <FormControl>
                                                                <SelectTrigger>
                                                                    <SelectValue placeholder="Select Age of Construction" />
                                                                </SelectTrigger>
                                                            </FormControl>
                                                            <SelectContent>
                                                                {Object.values(AgeofC).map((ageofconstruction) => (
                                                                    <SelectItem
                                                                        key={ageofconstruction}
                                                                        value={ageofconstruction}
                                                                    >
                                                                        {ageofconstruction}
                                                                    </SelectItem>
                                                                ))}
                                                            </SelectContent>
                                                        </Select>
                                                        <FormMessage />
                                                    </FormItem>
                                                )}
                                            />
                                        ) : (
                                            <p></p>
                                        )}

                                    </div>
                                )}

                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    {balconyShow.includes(balconyCheck) && (
                                        <FormField
                                            control={form.control}
                                            name="balcony"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Balconies</FormLabel>
                                                    <FormControl>
                                                        <div className="relative">
                                                            <BedDouble className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                                                            <Input
                                                                {...field}
                                                                type="number"
                                                                className="pl-10"
                                                                placeholder="1"
                                                                onChange={(e) => field.onChange(e.target.valueAsNumber)}
                                                            />
                                                        </div>
                                                    </FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                    )}
                                    {totalFloorsShow.includes(totalFloorsCheck) && (
                                        <FormField
                                            control={form.control}
                                            name="totalFloors"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Total Floors</FormLabel>
                                                    <FormControl>
                                                        <div className="relative">
                                                            <BedDouble className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                                                            <Input
                                                                {...field}
                                                                type="number" // This ensures it's a number input
                                                                className="pl-10" // Padding to account for the icon
                                                                placeholder="3"
                                                                onChange={(e) => field.onChange(e.target.valueAsNumber)} // Ensure number is parsed
                                                                min={0} // Optional: enforce a minimum value, e.g., 0 for positive numbers
                                                                step={1} // Optional: specify the step value, default is 1 for integer input
                                                            />
                                                        </div>
                                                    </FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />

                                    )}

                                    {propsWithPossessionStatusAndFurnishing.includes(selectedPropertyType) && (
                                        <FormField
                                            control={form.control}
                                            name="floorNumber"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Floor Number of your property</FormLabel>
                                                    <FormControl>
                                                        <div className="relative">
                                                            <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                                                            <Input
                                                                {...field}
                                                                className="pl-10"
                                                                placeholder="Basement, Ground, 1st, 2nd, etc."
                                                            />
                                                        </div>
                                                    </FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                    )}
                                    {roomShow.includes(bedroomShow) && (

                                        <FormField
                                            control={form.control}
                                            name="bedrooms"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Bedrooms</FormLabel>
                                                    <FormControl>
                                                        <div className="relative">
                                                            <BedDouble className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                                                            <Input
                                                                {...field}
                                                                type="number"
                                                                className="pl-10"
                                                                placeholder="3"
                                                                onChange={(e) => field.onChange(e.target.valueAsNumber)}
                                                            />
                                                        </div>
                                                    </FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />



                                    )}

                                    {/* // BATHROOM CHECKING */}
                                    {bathroomShow.includes(bathroomCheck) && (
                                        <FormField
                                            control={form.control}
                                            name="bathrooms"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Bathrooms</FormLabel>
                                                    <FormControl>
                                                        <div className="relative">
                                                            <Bath className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                                                            <Input
                                                                {...field}
                                                                type="number"
                                                                className="pl-10"
                                                                placeholder="2"
                                                                onChange={(e) => field.onChange(e.target.valueAsNumber)}
                                                            />
                                                        </div>
                                                    </FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                    )}
                                    <FormField
                                        control={form.control}
                                        name="area"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>
                                                    Area (sq ft)
                                                </FormLabel>
                                                <FormControl>
                                                    <div className="relative">
                                                        <Maximize className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                                                        <Input
                                                            {...field}
                                                            type="number"
                                                            className="pl-10"
                                                            placeholder="1500"
                                                            onChange={(e) => field.onChange(e.target.valueAsNumber)}
                                                        />
                                                    </div>
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={form.control}
                                        name="amountofbooking"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Amount/Token of Booking (Optional)</FormLabel>
                                                <FormControl>
                                                    <Input
                                                        {...field}
                                                        type="text"
                                                        placeholder="Amount/Token of Booking"
                                                    />
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />

                                    {plotCheck === "Showroom" && (
                                        <FormField
                                            control={form.control}
                                            name="cornorshowroom"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormControl>
                                                        <div className="flex space-x-2 text-gray-600 justify-center items-center">
                                                            <input
                                                                id="conoreshowroom"
                                                                type="checkbox"
                                                                checked={field.value}
                                                                onChange={(e) => field.onChange(e.target.checked)}
                                                                className="form-checkbox"
                                                            />
                                                            {/* Associate label with the checkbox using htmlFor */}
                                                            <FormLabel htmlFor="conoreshowroom">Conor Showroom</FormLabel>
                                                        </div>
                                                    </FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                    )}

                                    {/* //PLOT  AREAAAAAAAAAAAAAAAAAAAAaa*/}
                                    {(plotCheck === "Plot" || plotCheck == "Commercial Land" || plotCheck == "Industrial Land" || plotCheck == "Agricultural Land") && (
                                        <>
                                            {/* Input Fields First */}
                                            <FormField
                                                control={form.control}
                                                name="widthofroadfacing"
                                                render={({ field }) => (
                                                    <FormItem>
                                                        <FormLabel>Width of Road Facing</FormLabel>
                                                        <FormControl>
                                                            <Input
                                                                {...field}
                                                                type="text"
                                                                placeholder="Enter width of road facing"
                                                            />
                                                        </FormControl>
                                                        <FormMessage />
                                                    </FormItem>
                                                )}
                                            />

                                            <FormField
                                                control={form.control}
                                                name="nooffloorsallowed"
                                                render={({ field }) => (
                                                    <FormItem>
                                                        <FormLabel>Number of Floors Allowed</FormLabel>
                                                        <FormControl>
                                                            <Input
                                                                {...field}
                                                                type="number"
                                                                placeholder="Enter number of floors allowed"
                                                                onChange={(e) => field.onChange(e.target.valueAsNumber)}
                                                            />
                                                        </FormControl>
                                                        <FormMessage />
                                                    </FormItem>
                                                )}
                                            />

                                            <FormField
                                                control={form.control}
                                                name="noofopenside"
                                                render={({ field }) => (
                                                    <FormItem>
                                                        <FormLabel>Number of Open Sides</FormLabel>
                                                        <FormControl>
                                                            <Input
                                                                {...field}
                                                                type="number"
                                                                placeholder="Enter number of open sides"
                                                                onChange={(e) => field.onChange(e.target.valueAsNumber)}
                                                            />
                                                        </FormControl>
                                                        <FormMessage />
                                                    </FormItem>
                                                )}
                                            />

                                            <FormField
                                                control={form.control}
                                                name="plotlenght"
                                                render={({ field }) => (
                                                    <FormItem>
                                                        <FormLabel>Plot Length</FormLabel>
                                                        <FormControl>
                                                            <Input
                                                                {...field}
                                                                type="number"
                                                                placeholder="Enter plot length"
                                                                onChange={(e) => field.onChange(e.target.valueAsNumber)}
                                                            />
                                                        </FormControl>
                                                        <FormMessage />
                                                    </FormItem>
                                                )}
                                            />
                                            <FormField
                                                control={form.control}
                                                name="approvalauth"
                                                render={({ field }) => (
                                                    <FormItem>
                                                        <FormLabel>Approval Authority</FormLabel>
                                                        <Select
                                                            onValueChange={
                                                                field.onChange

                                                            }
                                                            defaultValue={field.value}
                                                        >
                                                            <FormControl>
                                                                <SelectTrigger>
                                                                    <SelectValue placeholder="Approval Authority" />
                                                                </SelectTrigger>
                                                            </FormControl>
                                                            <SelectContent>
                                                                {Object.values(
                                                                    Authority
                                                                ).map((approvalauth) => (
                                                                    <SelectItem
                                                                        key={approvalauth}
                                                                        value={approvalauth}
                                                                    >
                                                                        {approvalauth}
                                                                    </SelectItem>
                                                                ))}
                                                            </SelectContent>
                                                        </Select>
                                                        <FormMessage />
                                                    </FormItem>
                                                )}
                                            />
                                            <FormField
                                                control={form.control}
                                                name="plotwidth"
                                                render={({ field }) => (
                                                    <FormItem>
                                                        <FormLabel>Plot Width</FormLabel>
                                                        <FormControl>
                                                            <Input
                                                                {...field}
                                                                type="number"
                                                                placeholder="Enter plot width"
                                                                onChange={(e) => field.onChange(e.target.valueAsNumber)}
                                                            />
                                                        </FormControl>
                                                        <FormMessage />
                                                    </FormItem>
                                                )}
                                            />

                                            {/* Checkboxes at the End */}
                                        </>
                                    )}
                                </div>

                                <div className="flex md:flex-row flex-col space-y-2 items-center space-x-5 md:space-y-0 py-2">
                                    {(plotCheck === "Plot" || plotCheck === "Industrial Land" || plotCheck == "Commerical Land" || plotCheck === "Agricultural Land") && (
                                        <FormField
                                            control={form.control}
                                            name="constructiondone"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <label className="flex items-center space-x-2">
                                                        <input
                                                            type="checkbox"
                                                            checked={field.value || false}
                                                            onChange={(e) => field.onChange(e.target.checked)}
                                                            className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                                                        />
                                                        <span>Any Construction Done</span>
                                                    </label>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                    )}
                                    {(plotCheck === "Plot" || plotCheck === "Industrial Land" || plotCheck == "Commerical Land" || plotCheck === "Agricultural Land") && (
                                        <FormField
                                            control={form.control}
                                            name="boundrywall"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <label className="flex items-center space-x-2">
                                                        <input
                                                            type="checkbox"
                                                            checked={field.value || false}
                                                            onChange={(e) => field.onChange(e.target.checked)}
                                                            className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                                                        />
                                                        <span>Boundary Wall</span>
                                                    </label>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                    )}
                                    {plotCheck === "Plot" && (
                                        <FormField
                                            control={form.control}
                                            name="gatedcommunity"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <label className="flex items-center space-x-2">
                                                        <input
                                                            type="checkbox"
                                                            checked={field.value || false}
                                                            onChange={(e) => field.onChange(e.target.checked)}
                                                            className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                                                        />
                                                        <span>Gated Community</span>
                                                    </label>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />

                                    )}
                                    {(plotCheck === "Plot" || plotCheck === "Shop" || plotCheck === "Showroom") && (
                                        <FormField
                                            control={form.control}
                                            name="mainroadfacing"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <label className="flex items-center space-x-2">
                                                        <input
                                                            type="checkbox"
                                                            checked={field.value || false}
                                                            onChange={(e) => field.onChange(e.target.checked)}
                                                            className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                                                        />
                                                        <span>Main Road Facing</span>
                                                    </label>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                    )}
                                    {(plotCheck === "Office Space" || plotCheck === "Office in IT Park/SEZ" || plotCheck === "Shop") && (
                                        <FormField
                                            control={form.control}
                                            name="cafeteria"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <label className="flex items-center space-x-2">
                                                        <input
                                                            type="checkbox"
                                                            checked={field.value || false}
                                                            onChange={(e) => field.onChange(e.target.checked)}
                                                            className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                                                        />
                                                        <span>Cafeteria</span>
                                                    </label>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                    )}
                                    {plotCheck === "Shop" && (
                                        <FormField
                                            control={form.control}
                                            name="personalwashroom"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <label className="flex items-center space-x-2">
                                                        <input
                                                            type="checkbox"
                                                            checked={field.value || false}
                                                            onChange={(e) => field.onChange(e.target.checked)}
                                                            className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                                                        />
                                                        <span>Personal Washroom</span>
                                                    </label>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                    )}

                                </div>



                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <FormField
                                        control={form.control}
                                        name="areaunit"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Select a Unit</FormLabel>
                                                <Select
                                                    onValueChange={field.onChange}
                                                    defaultValue={field.value || FurnishingStatus.FURNISHED}
                                                >
                                                    <FormControl>
                                                        <SelectTrigger>
                                                            <SelectValue placeholder="Select Furnishing Status" />
                                                        </SelectTrigger>
                                                    </FormControl>
                                                    <SelectContent>
                                                        {Object.values(AreaUnit).map((area) => (
                                                            <SelectItem key={area} value={area}>
                                                                {area}
                                                            </SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={form.control}
                                        name="carpetarea"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Carpet Area</FormLabel>
                                                <FormControl>
                                                    <Input
                                                        {...field}
                                                        placeholder="Carpet Area"
                                                    />
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={form.control}
                                        name="superarea"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Super Area</FormLabel>
                                                <FormControl>
                                                    <Input
                                                        {...field}
                                                        placeholder="Super Area"
                                                    />
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />

                                </div>

                                <FormField
                                    control={form.control}
                                    name="address"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Address</FormLabel>
                                            <FormControl>
                                                <div className="relative">
                                                    <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                                                    <Input
                                                        {...field}
                                                        className="pl-10"
                                                        placeholder="123 Main St"
                                                    />
                                                </div>
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />

                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <FormField
                                        control={form.control}
                                        name="city"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>City</FormLabel>
                                                <FormControl>
                                                    <Input
                                                        {...field}
                                                        placeholder="New York"
                                                    />
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={form.control}
                                        name="state"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>State</FormLabel>
                                                <FormControl>
                                                    <Input
                                                        {...field}
                                                        placeholder="NY"
                                                    />
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={form.control}
                                        name="zipCode"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Zip Code</FormLabel>
                                                <FormControl>
                                                    <Input
                                                        {...field}
                                                        placeholder="10001"
                                                    />
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                </div>

                                <FormField
                                    control={form.control}
                                    name="amenities"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Amenities</FormLabel>
                                            <div className="grid grid-cols-2 gap-2">
                                                {amenitiesList.map(
                                                    (amenity) => (
                                                        <label
                                                            key={amenity}
                                                            className="flex items-center space-x-2"
                                                        >
                                                            <Checkbox
                                                                checked={field.value?.includes(
                                                                    amenity
                                                                )}
                                                                onCheckedChange={(
                                                                    checked
                                                                ) => {
                                                                    return checked
                                                                        ? field.onChange(
                                                                            [
                                                                                ...(field.value ||
                                                                                    []),
                                                                                amenity,
                                                                            ]
                                                                        )
                                                                        : field.onChange(
                                                                            field.value?.filter(
                                                                                (
                                                                                    value
                                                                                ) =>
                                                                                    value !==
                                                                                    amenity
                                                                            )
                                                                        );
                                                                }}
                                                            />
                                                            <span className="text-sm text-gray-700">
                                                                {amenity}
                                                            </span>
                                                        </label>
                                                    )
                                                )}
                                            </div>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />

                                <FormField
                                    control={form.control}
                                    name="images"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Property Images</FormLabel>
                                            <FormControl>
                                                <div
                                                    {...getRootProps()}
                                                    className={`border-2 border-dashed rounded-md p-4 text-center cursor-pointer ${isDragActive
                                                        ? "border-cyan-500 bg-cyan-50"
                                                        : "border-gray-300"
                                                        }`}
                                                >
                                                    <input {...getInputProps()} />
                                                    {isDragActive ? (
                                                        <p className="text-cyan-500">
                                                            Drop the files here ...
                                                        </p>
                                                    ) : (
                                                        <p>
                                                            Drag 'n' drop some files here, or click
                                                            to select files
                                                        </p>
                                                    )}
                                                    <p className="text-sm text-gray-500 mt-2">
                                                        (Only *.jpeg, *.png and *.webp images will be
                                                        accepted)
                                                    </p>
                                                </div>
                                            </FormControl>
                                            <FormMessage />
                                            {field.value && field.value.length > 0 && (
                                                <div className="mt-4 grid grid-cols-2 md:grid-cols-3 gap-4">
                                                    {imageFiles.map((file, index) => (
                                                        <div key={index} className="relative">
                                                            <img
                                                                src={URL.createObjectURL(file)}
                                                                alt={`Uploaded image ${index + 1}`}
                                                                className="w-full h-32 object-cover rounded-md"
                                                            />
                                                            <button
                                                                type="button"
                                                                onClick={() => removeImage(index)}
                                                                className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1"
                                                                aria-label={`Remove image ${index + 1}`}
                                                            >
                                                                <X size={16} />
                                                            </button>
                                                        </div>
                                                    ))}
                                                </div>
                                            )}
                                        </FormItem>
                                    )}
                                />

                                <Button
                                    type="submit"
                                    className="w-full bg-cyan text-white"
                                >
                                    {isSubmitting
                                        ? "Submitting..."
                                        : initialData
                                            ? "Update Property"
                                            : "List Property"}
                                </Button>
                            </form>
                        </Form>
                    </div>
                </div>
            </div>
        </>
    );
}
