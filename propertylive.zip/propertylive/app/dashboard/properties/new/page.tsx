// app/dashboard/properties/new/page.tsx
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react'; // Import useSession
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from "@/components/ui/use-toast";
import PropertyForm from '../PropertyForm';
import { PropertyFormData } from '../PropertyForm';

export default function NewPropertyPage() {
  const { data: session, status } = useSession(); // Get session and status
  const router = useRouter();


  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/signin'); // Redirect to login if not authenticated
    }
  }, [status, router]);

  

  // Don't render form if the session status is still loading or unauthenticated
  if (status === 'loading') {
    return <div>Loading...</div>;
  }

  return (
    <div className='relative'>
      <Card>
        <CardHeader>
          <CardTitle className='md:text-2xl'>Add New Property</CardTitle>
        </CardHeader>
        <CardContent>
          {/* Render form only if the user is authenticated */}
          {status === 'authenticated' && (
            <PropertyForm />
          )}
        </CardContent>
      </Card>
    </div>
  );
}
