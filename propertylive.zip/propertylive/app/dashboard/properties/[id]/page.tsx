import { notFound } from 'next/navigation';
import Link from 'next/link';
import { getServerSession } from 'next-auth/next';
import prisma from '@/lib/prisma';
import {
    FaTag, FaBed, FaBath, FaRulerCombined, FaMapMarkerAlt, FaUser,
    FaBuilding, FaClipboardList, FaClock, FaListAlt, FaDoorClosed, FaCheckCircle
} from "react-icons/fa";
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import InquiryForm from '@/components/InquiryForm';
import DeletePropertyButton from '@/app/dashboard/properties/DeletePropertyButton';
import PropertyValuation from './PropertyValuation';
import ImageGallery from './ImageGallery';
import pictures from '@/public/dummy-apartment-1.jpg';

type Property = {
    id: string;
    propertyType?: string;
    title: string;
    description: string;
    price?: number;
    type?: string;
    category?: string; // Assuming PropertyCategory is a string or adjust as per your actual type
    status?: string; // Assuming PropertyStatus is a string or adjust as per your actual type
    postedAs?: string;
    bedrooms?: number;
    bathrooms?: number;
    balcony?: number;
    area?: number;
    address?: string;
    city?: string;
    state?: string;
    zipCode?: string;
    amenities?: string[];
    images?: string[];
    furnishingStatus?: string;
    floorNumber?: string;
    totalFloors?: number;
    facing?: string;
    postedBy?: string; // Assuming UserRole is a string or adjust as per your actual type
    possessionStatus?: string; // Assuming PossessionStatus is a string or adjust as per your actual type
    tenantsPreferred?: string; // Assuming TenantsPreferred is a string or adjust as per your actual type
    availableFrom?: string; // Assuming AvailableFrom is a string or adjust as per your actual type
    saleType?: string; // Assuming SaleType is a string or adjust as per your actual type
    reraRegistered?: boolean;
    verified?: boolean;
    exclusive?: boolean;
    createdAt: Date;
    updatedAt: Date;
    userId: string;
    expectedprice?: number;
    pricenegotiablen?: boolean;
    bookingtoken?: boolean;
    plotspecialization?: string;
    widthofroadfacing?: string;
    constructiondone?: boolean;
    boundrywall?: boolean;
    gatedcommunity?: boolean;
    approvalauth?: string; // Assuming Authority is a string or adjust as per your actual type
    nooffloorsallowed?: number;
    nooofpenside?: number;
    plotlenght?: string;
    plotwidth?: string;
    ageofconstruction?: string; // Assuming AgeofC is a string or adjust as per your actual type
    amountofbooking?: number;
    mainroadfacing?: boolean;
    cafeteria?: boolean;
    cornorshowroom?: boolean;
    personalwashroom?: boolean;
    carpetArea?: number;
    superArea?: number;
    areaunit?: string; // Assuming AreaUnit is a string or adjust as per your actual type
    user: {
        name: string;
        email: string;
        phone?: string;
    };
};


type Params = {
    id: string;
};

// Property type arrays for conditional rendering
const bathroomShow = ["Shop", "Office in IT Park/SEZ", "Office Space", "Flat/Apartment", "House", "Villa", "Builder Floor", "Studio Apartment", "Penthouse", "Farmhouse"];
const roomShow = ["Flat/Apartment", "House", "Villa", "Builder Floor", "Studio Apartment", "Penthouse", "Farmhouse"];
const totalFloorsShow = ["Flat/Apartment", "House", "Villa", "Builder Floor", "Studio Apartment", "Penthouse", "Farmhouse", "Office Space", "Office in IT Park/SEZ", "Shop", "Showroom", "Industrial Building", "Industrial Shed", "Warehouse"];
const propsWithPossessionStatusAndFurnishing = ["Flat/Apartment", "House", "Villa", "Builder Floor", "Studio Apartment", "Penthouse", "Farmhouse", "Office Space", "Office in IT Park/SEZ", "Shop", "Showroom", "Warehouse", "Industrial Building", "Industrial Shed"];
const balconyShow = ["Flat/Apartment", "House", "Villa", "Builder Floor", "Studio Apartment", "Penthouse", "Farmhouse"];
const nonofFloors = ["Commercial Land", "Industrial Land", "Agricultural Land", "Plot"];

type PropertyWithoutUser = Omit<Property, 'user'>;


async function getProperty(id: string): Promise<PropertyWithoutUser> {
    const property = await prisma.property.findUnique({
        where: { id },
    });

    if (!property) {
        notFound();
    }

    return {
        id: property.id,
        // propertyType: property.propertyType ?? undefined,
        title: property.title ?? "Untitled",
        description: property.description ?? "",
        price: property.price ?? undefined,
        type: property.type ?? undefined,
        // category: property.category ?? undefined,
        // status: property.status ?? undefined,
        postedAs: property.postedAs ?? undefined,
        bedrooms: property.bedrooms ?? undefined,
        bathrooms: property.bathrooms ?? undefined,
        balcony: property.balcony ?? undefined,
        area: property.area ?? undefined,
        address: property.address ?? "",
        city: property.city ?? "",
        state: property.state ?? "",
        zipCode: property.zipCode ?? "",
        amenities: property.amenities ?? [],
        images: property.images ?? [],
        furnishingStatus: property.furnishingStatus ?? undefined,
        floorNumber: property.floorNumber ?? undefined,
        totalFloors: property.totalFloors ?? undefined,
        facing: property.facing ?? undefined,
        postedBy: property.postedBy ?? undefined,
        possessionStatus: property.possessionStatus ?? undefined,
        tenantsPreferred: property.tenantsPreferred ?? undefined,
        availableFrom: property.availableFrom ?? undefined,
        saleType: property.saleType ?? undefined,
        reraRegistered: property.reraRegistered ?? false,
        verified: property.verified ?? false,
        exclusive: property.exclusive ?? false,
        createdAt: property.createdAt,
        updatedAt: property.updatedAt,
        userId: property.userId,
        expectedprice: property.expectedprice ? parseFloat(property.expectedprice) : undefined,
        pricenegotiablen: property.pricenegotiablen ?? true,
        bookingtoken: property.bookingtoken ?? false,
        plotspecialization: property.plotspecialization ?? undefined,
        widthofroadfacing: property.widthofroadfacing ?? undefined,
        constructiondone: property.constructiondone ?? false,
        boundrywall: property.boundrywall ?? false,
        gatedcommunity: property.gatedcommunity ?? true,
        approvalauth: property.approvalauth ?? undefined,
        nooffloorsallowed: property.nooffloorsallowed ?? undefined,
        nooofpenside: property.noofopenside ?? undefined,
        plotlenght: property.plotlenght ? property.plotlenght.toString() : undefined,
        plotwidth: property.plotwidth ? property.plotwidth.toString() : undefined,
        ageofconstruction: property.ageofconstruction ?? undefined,
        amountofbooking: property.amountofbooking ? parseFloat(property.amountofbooking) : undefined,
        mainroadfacing: property.mainroadfacing ?? false,
        cafeteria: property.cafeteria ?? false,
        cornorshowroom: property.cornorshowroom ?? false,
        personalwashroom: property.personalwashroom ?? false,
        carpetArea: property.carpetarea != null ? property.carpetarea : undefined,
        superArea: property.superarea !== null ? property.superarea : undefined,
        areaunit: property.areaunit ?? undefined,
    };
}

async function getUserInfo(id: string): Promise<{ name: string; email?: string; phone?: string }> {
    const user = await prisma.user.findUnique({
        where: { id },
    });

    // Map the user object to only include the required fields
    if (!user) {
        return { name: "No Information Present" };
    }

    return {
        name: user.name ?? "No Information Present",
        email: user.email ?? undefined,
        phone: user.phone ?? undefined,
    };
}

export default async function PropertyDetailPage({ params }: { params: Params }) {
    const property = await getProperty(params.id);
    const user = await getUserInfo(property.userId);
    const session = await getServerSession();
    const isOwner = session?.user?.id === property.userId;

    return (
        <div className="container mx-auto px-4 py-8">
            <Card className="shadow-md rounded-lg overflow-hidden mb-8">
                <CardHeader className="bg-neutral-900 p-4 rounded-t-lg text-white">
                    <CardTitle className="text-2xl">{property.title}</CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                    <div className="flex flex-col text-center">
                        <div>
                            <ImageGallery images={property.images?.map(String) || [pictures.src]} />
                        </div>
                        <div className="flex flex-col md:flex-row justify-between my-3">
                            <div className="space-y-2 text-gray-700">
                                {/* Display Price */}
                                {property.price && (
                                    <p className="text-3xl font-bold text-cyan mb-4 flex items-center">
                                        <FaTag className="mr-2" /> ${property.price.toLocaleString()}
                                    </p>
                                )}

                                {/* Price Negotiable */}
                                {property.pricenegotiablen && (
                                    <p className="flex items-center">
                                        <FaTag className="mr-2" /> Price Negotiable
                                    </p>
                                )}
                                {property.gatedcommunity && (
                                    <p className="flex items-center">
                                        <FaTag className="mr-2" /> Gated Communtiy
                                    </p>
                                )}
                                 {property.boundrywall && (
                                    <p className="flex items-center">
                                        <FaTag className="mr-2" /> Boundry Wall
                                    </p>
                                )}
                                  {property.mainroadfacing && (
                                    <p className="flex items-center">
                                        <FaTag className="mr-2" /> Main Road Facing
                                    </p>
                                )}
                                  {property.constructiondone && (
                                    <p className="flex items-center">
                                        <FaTag className="mr-2" /> Some Construction Done
                                    </p>
                                )}
                                {property.type === "Office Space" && property.cafeteria && (
                                    <p className="flex items-center">
                                        <FaTag className="mr-2" /> Cafeteria Available
                                    </p>
                                )}

                                {/* Display Bedrooms */}
                                {roomShow.includes(property.type || '') && property.bedrooms != null && (
                                    <p className="flex items-center">
                                        <FaBed className="mr-2" /> Bedrooms: {property.bedrooms}
                                    </p>
                                )}

                                {/* Display Property Type */}
                                <p className="flex items-center">
                                    <FaBuilding className="mr-2" /> Property Type: {property.type}
                                </p>
                                <p className="flex items-center">
                                    <FaBuilding className="mr-2" /> Sale Type: {property.saleType}
                                </p>

                                {/* Display Bathrooms */}
                                {bathroomShow.includes(property.type || '') && property.bathrooms != null && (
                                    <p className="flex items-center">
                                        <FaBath className="mr-2" /> Bathrooms: {property.bathrooms}
                                    </p>
                                )}

                                {/* Display Balconies */}
                                {balconyShow.includes(property.type || '') && property.balcony != null && (
                                    <p className="flex items-center">
                                        <FaBuilding className="mr-2" /> Balconies: {property.balcony}
                                    </p>
                                )}

                                {/* Display Area */}
                                {property.area && (
                                    <p className="flex items-center">
                                        <FaRulerCombined className="mr-2" /> Area: {property.area} sq ft
                                    </p>
                                )}

                                {/* Display Location */}
                                {property.address && property.city && property.state && property.zipCode && (
                                    <p className="flex items-center">
                                        <FaMapMarkerAlt className="mr-2" /> Location: {property.address}, {property.city}, {property.state} {property.zipCode}
                                    </p>
                                )}

                                {/* Display Posted As */}
                                {property.postedAs && (
                                    <p className="flex items-center">
                                        <FaUser className="mr-2" /> Posted As: {property.postedAs}
                                    </p>
                                )}

                                {/* Display Furnishing Status */}
                                {propsWithPossessionStatusAndFurnishing.includes(property.type || '') && property.furnishingStatus && (
                                    <p className="flex items-center">
                                        <FaClipboardList className="mr-2" /> Furnishing Status: {property.furnishingStatus}
                                    </p>
                                )}
                                {nonofFloors.includes(property.type || '') && (
                                    <p className="flex items-center">
                                        <FaClipboardList className="mr-2" /> Number of Floors Allowed: {property.nooffloorsallowed}
                                    </p>
                                )}

                                {/* Display Floor Number */}
                                {property.floorNumber && (
                                    <p className="flex items-center">
                                        <FaClipboardList className="mr-2" /> Floor Number: {property.floorNumber}
                                    </p>
                                )}

                                {/* Display Total Floors */}
                                {totalFloorsShow.includes(property.type || '') && property.totalFloors != null && (
                                    <p className="flex items-center">
                                        <FaClipboardList className="mr-2" /> Total Floors: {property.totalFloors}
                                    </p>
                                )}

                                {/* Display Facing Direction */}
                                {property.facing && (
                                    <p className="flex items-center">
                                        <FaDoorClosed className="mr-2" /> Facing: {property.facing}
                                    </p>
                                )}
                                {(property.type === "Plot" || property.type === "Commercial Land" || property.type === "Industrial Land" || property.type === "Agricultural Land") && property.widthofroadfacing && (
                                    <p className="flex items-center">
                                        <FaRulerCombined className="mr-2" /> Width of Road Facing: {property.widthofroadfacing}
                                    </p>
                                )}



                                {/* Display Possession Status */}
                                {propsWithPossessionStatusAndFurnishing.includes(property.type || '') && property.possessionStatus && (
                                    <p className="flex items-center">
                                        <FaClock className="mr-2" /> Possession Status: {property.possessionStatus}
                                    </p>
                                )}
                                {/* Display Available From or Age of Construction */}
                                {propsWithPossessionStatusAndFurnishing.includes(property.type || '') && property.possessionStatus && (
                                    property.possessionStatus === "UNDER_CONSTRUCTION" ? (
                                        property.availableFrom && (
                                            <p className="flex items-center">
                                                <FaClock className="mr-2" /> Available From: {property.availableFrom}
                                            </p>
                                        )
                                    ) : (
                                        property.ageofconstruction && (
                                            <p className="flex items-center">
                                                <FaClock className="mr-2" /> Age of Construction: {property.ageofconstruction}
                                            </p>
                                        )
                                    )
                                )}

                                {/* Display Sale Type */}
                                {property.saleType && (
                                    <p className="flex items-center">
                                        <FaListAlt className="mr-2" /> Sale Type: {property.saleType}
                                    </p>
                                )}

                                {/* Display RERA Registration Status */}
                                {property.reraRegistered != null && (
                                    <p className="flex items-center">
                                        <FaListAlt className="mr-2" /> RERA Registered: {property.reraRegistered ? "Yes" : "No"}
                                    </p>
                                )}

                                {/* Display Carpet Area */}
                                {property.carpetArea != null && (
                                    <p className="flex items-center">
                                        <FaBuilding className="mr-2" /> Carpet Area: {property.carpetArea} {property.areaunit}
                                    </p>
                                )}
                                <p className="flex items-center">
                                    <FaBuilding className="mr-2" /> Width of Road Facing:  {property.widthofroadfacing}
                                </p>
                               {(property.type === "Plot" || property.type === "Commercial Land" || property.type === "Industrial Land" || property.type === "Agricultural Land") && property.plotlenght && (
                                <div className='space-y-2'>
                                     <p className="flex items-center">
                                    <FaBuilding className="mr-2" /> Plot Length:  {property.plotlenght}
                                </p>
                                <p className="flex items-center">
                                    <FaBuilding className="mr-2" /> Plot Width:  {property.plotwidth}
                                </p>
                                
                                </div>
                               )}
                                {/* Display Super Area */}
                                {property.superArea != null && (
                                    <p className="flex items-center">
                                        <FaBuilding className="mr-2" /> Super Area: {property.superArea} {property.areaunit}
                                    </p>
                                )}

                                {/* Display Listed On Date */}
                                {property.createdAt && (
                                    <p className="flex items-center">
                                        <FaClock className="mr-2" /> Listed On: {new Date(property.createdAt).toLocaleDateString()}
                                    </p>
                                )}

                                {/* Display Booking Token Information */}
                                {property.bookingtoken ? (
                                    <p className="flex items-center">
                                        <FaBuilding className="mr-2" /> Amount of Booking: ${property.amountofbooking}
                                    </p>
                                ) : (
                                    <p className="flex items-center">
                                        <span className="font-semibold mr-2">Booking Token:</span> No booking token is required
                                    </p>
                                )}
                            </div>

                            {/* Owner's Details */}
                            <div className="text-gray-700 text-center">
                                <h1 className="font-semibold text-2xl text-center my-2">Owner's Details</h1>
                                <p className="flex items-center">
                                    <FaUser className="mr-2" /> Posted by: {user.name}
                                </p>
                                <p className="flex items-center">
                                    <FaUser className="mr-2" />
                                    Owner's Email: <a href={`mailto:${user.email}`} className="text-blue-500 hover:underline mx-2">{user.email}</a>
                                </p>
                                {user.phone && (
                                    <p className="flex items-center">
                                        <FaUser className="mr-2" />
                                        Owner's Phone: <a href={`tel:${user.phone}`} className="text-blue-500 hover:underline mx-2">{user.phone}</a>
                                    </p>
                                )}
                            </div>

                            {isOwner && (
                                <div className="mt-6 flex space-x-4">
                                    <Button asChild>
                                        <Link href={`/dashboard/properties/edit/${property.id}`}>
                                            Edit Property
                                        </Link>
                                    </Button>
                                    <DeletePropertyButton propertyId={property.id} />
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Description */}
                    <div className="mt-8">
                        <h3 className="text-xl font-semibold mb-4">Description</h3>
                        <p className="text-gray-600">{property.description}</p>
                    </div>

                    {/* Amenities */}
                    {property.amenities && property.amenities.length > 0 && (
                        <div className="mt-8">
                            <h3 className="text-xl font-semibold mb-4">Amenities</h3>
                            <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {property.amenities.map((amenity, index) => (
                                    <li key={index} className="flex items-center text-gray-600">
                                        <FaCheckCircle className="text-green-500 mr-2" /> {amenity}
                                    </li>
                                ))}
                            </ul>
                        </div>
                    )}
                </CardContent>
            </Card>

            {/* Property Valuation and Inquiry Form */}
            <div className="flex flex-col md:flex-row items-start justify-between space-y-6 md:space-y-0 md:space-x-6 mt-8">
                <Card className="md:w-1/2 w-full shadow-md rounded-lg p-6">
                    <PropertyValuation propertyId={property.id} />
                </Card>
                {!isOwner && (
                    <Card className="md:w-1/2 w-full shadow-md rounded-lg p-6">
                        <InquiryForm propertyId={params.id} />
                    </Card>
                )}
            </div>
        </div>

    );
}
