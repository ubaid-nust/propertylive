// app/properties/[id]/PropertyValuation.tsx
'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';

interface Valuation {
  id: string;
  value: number;
  date: string;
  appraiserName: string;
}

export default function PropertyValuation({ propertyId }: { propertyId: string }) {
  const { data: session } = useSession();
  const router = useRouter();
  const { toast } = useToast();
  const [valuations, setValuations] = useState<Valuation[]>([]);
  const [newValuation, setNewValuation] = useState({ value: '', appraiserName: '' });
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    fetchValuations();
  }, [propertyId]);

  const fetchValuations = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(`/api/property-valuations?propertyId=${propertyId}`);
      if (!response.ok) throw new Error('Failed to fetch valuations');
      const data = await response.json();
      setValuations(data);
    } catch (error) {
      console.error('Error fetching valuations:', error);
      toast({
        title: 'Error',
        description: 'Failed to fetch property valuations',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const response = await fetch('/api/property-valuations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          propertyId,
          value: parseFloat(newValuation.value),
          appraiserName: newValuation.appraiserName,
        }),
      });
      if (!response.ok) throw new Error('Failed to add valuation');
      toast({ title: 'Success', description: 'Valuation added successfully' });
      setNewValuation({ value: '', appraiserName: '' });
      fetchValuations();
    } catch (error) {
      console.error('Error adding valuation:', error);
      toast({
        title: 'Error',
        description: 'Failed to add valuation',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) return <div className='text-white'>Loading valuations...</div>;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Property Valuations</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          {valuations.map((valuation) => (
            <div key={valuation.id} className="mb-2">
              <p>Value: ${valuation.value.toLocaleString()}</p>
              <p>Date: {new Date(valuation.date).toLocaleDateString()}</p>
              <p>Appraiser: {valuation.appraiserName}</p>
            </div>
          ))}
        </div>
        <form onSubmit={handleSubmit} className="space-y-4 ">
          <Input
            type="number"
            placeholder="Valuation Amount"
            value={newValuation.value}
            onChange={(e) => setNewValuation({ ...newValuation, value: e.target.value })}
            required
          />
          <Input
            placeholder="Appraiser Name"
            value={newValuation.appraiserName}
            onChange={(e) => setNewValuation({ ...newValuation, appraiserName: e.target.value })}
            required
          />
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? 'Adding...' : 'Add Valuation'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}