import { Suspense } from 'react';
import BlogPostList from './BlogPostList';

export default function BlogPage({ searchParams }: { searchParams: { page?: string, category?: string } }) {
  const page = searchParams.page || '1';
  const category = searchParams.category;

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-4">Blog Posts</h1>
      <Suspense fallback={<div>Loading...</div>}>
        <BlogPostList page={page} category={category} />
      </Suspense>
    </div>
  );
}