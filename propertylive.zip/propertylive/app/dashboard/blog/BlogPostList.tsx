// app/blog/BlogPostList.tsx
import Link from 'next/link';
import { getServerSession } from 'next-auth/next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"
import prisma from '@/lib/prisma';
import { Prisma, BlogCategory } from '@prisma/client';

async function getBlogPosts(page = 1, category?: string) {
  const pageSize = 10;
  const skip = (page - 1) * pageSize;

  const whereClause: Prisma.BlogPostWhereInput = category ? { category: category as BlogCategory } : {};

  const blogPosts = await prisma.blogPost.findMany({
    where: whereClause,
    skip,
    take: pageSize,
    orderBy: { createdAt: 'desc' },
  });

  const totalPosts = await prisma.blogPost.count({ where: whereClause });

  return {
    blogPosts,
    totalPages: Math.ceil(totalPosts / pageSize),
  };
}

export default async function BlogPostList({ page = '1', category }: { page?: string, category?: string }) {
  const pageNumber = parseInt(page);
  const { blogPosts, totalPages } = await getBlogPosts(pageNumber, category);
  const session = await getServerSession();
  const isAdmin = session?.user?.role === 'ADMIN';

  return (
    <div>
      {blogPosts.map((post) => (
        <Card key={post.id} className="mb-4">
          <CardHeader>
            <CardTitle>{post.title}</CardTitle>
          </CardHeader>
          <CardContent>
            <p>{post.content.substring(0, 150)}...</p>
            <p className="text-sm text-gray-500 mt-2">Category: {post.category}</p>
            <p className="text-sm text-gray-500">Author: {post.author}</p>
            <div className="mt-4">
              <Button asChild variant="outline">
                <Link href={`/blog/${post.id}`}>Read More</Link>
              </Button>
              {isAdmin && (
                <Button asChild variant="outline" className="ml-2">
                  <Link href={`/blog/edit/${post.id}`}>Edit</Link>
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
      <Pagination>
        <PaginationContent>
          <PaginationItem>
            <PaginationPrevious 
              href={pageNumber > 1 ? `/blog?page=${pageNumber - 1}${category ? `&category=${category}` : ''}` : '#'} 
              aria-disabled={pageNumber <= 1}
            />
          </PaginationItem>
          {[...Array(totalPages)].map((_, index) => (
            <PaginationItem key={index}>
              <PaginationLink 
                href={`/blog?page=${index + 1}${category ? `&category=${category}` : ''}`}
                isActive={pageNumber === index + 1}
              >
                {index + 1}
              </PaginationLink>
            </PaginationItem>
          ))}
          <PaginationItem>
            <PaginationNext 
              href={pageNumber < totalPages ? `/blog?page=${pageNumber + 1}${category ? `&category=${category}` : ''}` : '#'}
              aria-disabled={pageNumber >= totalPages}
            />
          </PaginationItem>
        </PaginationContent>
      </Pagination>
    </div>
  );
}   