// app/services/[id]/page.tsx
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { getServerSession } from 'next-auth/next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import prisma from '@/lib/prisma';

async function getService(id: string) {
  const service = await prisma.service.findUnique({
    where: { id },
  });

  if (!service) {
    notFound();
  }

  return service;
}

export default async function ServiceDetailPage({ params }: { params: { id: string } }) {
  const service = await getService(params.id);
  const session = await getServerSession();
  const isAdmin = session?.user?.role === 'ADMIN';

  return (
    <div className="container mx-auto px-4 py-8">
      <Card>
        <CardHeader>
          <CardTitle>{service.name}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">{service.description}</p>
          <p className="font-bold mb-2">Price: ${service.price}</p>
          <p className="mb-4">Category: {service.category}</p>
          {isAdmin && (
            <div className="mt-4">
              <Button asChild variant="outline" className="mr-2">
                <Link href={`/services/edit/${service.id}`}>Edit Service</Link>
              </Button>
              <Button variant="destructive">Delete Service</Button>
            </div>
          )}
          <Button asChild className="mt-4">
            <Link href="/dashboard/services">Back to Services</Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}