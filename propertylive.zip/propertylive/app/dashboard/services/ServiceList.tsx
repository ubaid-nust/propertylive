// app/services/ServiceList.tsx
import Link from 'next/link';
import { getServerSession } from 'next-auth/next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { authOptions } from '@/lib/auth'; 

import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"
import prisma from '@/lib/prisma';
import { Prisma, ServiceCategory } from '@prisma/client';

async function getServices(page = 1, category?: string) {
  const pageSize = 10;
  const skip = (page - 1) * pageSize;

  const whereClause: Prisma.ServiceWhereInput = category && category !== 'ALL'
    ? { category: category as ServiceCategory }
    : {};

  const services = await prisma.service.findMany({
    where: whereClause,
    skip,
    take: pageSize,
    orderBy: { createdAt: 'desc' },
  });

  const totalServices = await prisma.service.count({ where: whereClause });

  return {
    services,
    totalPages: Math.ceil(totalServices / pageSize),
  };
}

export default async function ServiceList({ page = '1', category }: { page?: string, category?: string }) {
  const pageNumber = parseInt(page);
  const { services, totalPages } = await getServices(pageNumber, category);
  const session = await getServerSession(authOptions);
  const isAdmin = session?.user?.role === 'ADMIN';

  return (
    <div>
      {services.map((service) => (
        <Card key={service.id} className="mb-4">
          <CardHeader>
            <CardTitle>{service.name}</CardTitle>
          </CardHeader>
          <CardContent>
            <p>{service.description}</p>
            <p className="font-bold mt-2">Price: ${service.price}</p>
            <p>Category: {service.category}</p>
            <div className="mt-4">
              <Button asChild variant="outline">
                <Link href={`/dashboard/services/${service.id}`}>View Details</Link>
              </Button>
              {isAdmin && (
                <Button asChild variant="outline" className="ml-2">
                  <Link href={`/dashboard/services/edit/${service.id}`}>Edit</Link>
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
      <Pagination>
        <PaginationContent>
          <PaginationItem>
            <PaginationPrevious 
              href={pageNumber > 1 ? `/services?page=${pageNumber - 1}${category ? `&category=${category}` : ''}` : '#'} 
              aria-disabled={pageNumber <= 1}
            />
          </PaginationItem>
          {[...Array(totalPages)].map((_, index) => (
            <PaginationItem key={index}>
              <PaginationLink 
                href={`/services?page=${index + 1}${category ? `&category=${category}` : ''}`}
                isActive={pageNumber === index + 1}
              >
                {index + 1}
              </PaginationLink>
            </PaginationItem>
          ))}
          <PaginationItem>
            <PaginationNext 
              href={pageNumber < totalPages ? `/services?page=${pageNumber + 1}${category ? `&category=${category}` : ''}` : '#'}
              aria-disabled={pageNumber >= totalPages}
            />
          </PaginationItem>
        </PaginationContent>
      </Pagination>
    </div>
  );
}