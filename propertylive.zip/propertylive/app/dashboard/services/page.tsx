// app/services/page.tsx
import { Suspense } from 'react';
import { getServerSession } from 'next-auth/next';
import Link from 'next/link';
import ServiceList from './ServiceList';
import ServiceFilter from './ServiceFilter';
import { Button } from '@/components/ui/button';
import { authOptions } from '@/lib/auth'; 


export default async function ServicesPage({
  searchParams
}: {
  searchParams: { page?: string; category?: string }
}) {
  const session = await getServerSession(authOptions);
  console.log(session)
  const isAdmin = session?.user?.role === 'ADMIN';

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Services</h1>
        {isAdmin && (
          <Button asChild>
            <Link href="/dashboard/services/new">Add New Service</Link>
          </Button>
        )}
      </div>
      <ServiceFilter />
      <Suspense fallback={<div>Loading services...</div>}>
        <ServiceList page={searchParams.page} category={searchParams.category} />
      </Suspense>
    </div>
  );
}